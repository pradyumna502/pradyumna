﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExam1
{
    public abstract class Account
    {
        // To know which type of account is created.
        public string TypeOfaccount { get; set; }
        // Account Owner is created.
        public int owner { get; set; }
        // Account balance is created.
        public decimal balance { get; set; }

        //Constructor of Account Class
        public Account(int owner, decimal balance)
        {
            this.owner = owner;
            this.balance = balance;
        }

        //Static accont number used for making account number
       // public static int accountNumberMarker = 1000;

        //Method or Function used for Creating a Customer
        //public static void CreateCustomer()
        //{
        //    //Calling of Type of Account Class 
        //    TypeofAccount accountype = new TypeofAccount();
        //    Console.Clear();

        //    Console.WriteLine("--- Create New Customer ---");
        //    Console.Write("Please enter the Account Holder Name: ");
        //    string name = Console.ReadLine();

        //    //Account number icrement by +1
        //    int id = ++accountNumberMarker;

        //    //Instantiate a Customer object
        //    Customer customer = new Customer();
        //    customer.Name = name;

        //    //Readline reads in a string, thus we cast id to integer
        //    customer.ID = id;
        //    Bank.AllCustomers.Add(customer);

        //    for (int i = 1; i <= 2; i++)
        //    {
        //        accountype.TypeOfaccount = i;
        //        accountype.owner = customer.ID;
        //        TypeofAccount.TypeOfaccounts.Add(accountype);
        //    }
        //    MainClass.ShowMainMenu();
        //}


    }
}
