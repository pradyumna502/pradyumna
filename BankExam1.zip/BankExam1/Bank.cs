﻿using System;
using System.Collections.Generic;

namespace BankExam1
{
    public abstract class Bank
    {
        //static modifier is shared between all the objects
        //list is a dynamic array(Collection class)
        //private static List<Transaction> transactions = new List<Transaction>();
        private static List<Customer> customers = new List<Customer>();


        /*
         Default constructor to create a list of Customers, but a bank is 
        instantiated with a empty constructor
        */
        public Bank()
        {
            //Instantiating a customer list        
            customers = new List<Customer>();
        }


        //property method to get a list of customers
        public static List<Customer> AllCustomers
        {
            get { return customers; }
        }
        public static void ShowAllCustomers()
        {
            string acctype = "";
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("-----------");


            /*Checking if the users are present in the bank.*/

            if (Bank.AllCustomers.Count == 0)
            {
                string name = "NO Customers. Please create Customers";
                Console.WriteLine(name);
                Console.WriteLine("-----------");
                Console.WriteLine();
                Console.ReadLine();
                MainClass.ShowMainMenu();
            }

            /*For each loop is used to pick the elements one by one from array or Collection,
             in the loop we instantiate a empty bank object*/
            else
            {
                foreach (Customer myCustomer in Bank.AllCustomers)
                {
                    Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n Saving Balance: " + myCustomer.SavingBalance + "krona" + "\n CheckingAccount Balance: " + myCustomer.CurrentBalance + "krona" + "\n MemberSince: " + myCustomer.dateString);
                    for (int i = 1; i <= 2; i++)
                    {
                        if (i == 1)
                        {
                            acctype = "Saving Account";
                        }
                        else
                        {
                            acctype = "Current Account";
                        }
                        // Console.WriteLine("Type of account: " + i + "   AccountType: " + acctype);
                    }

                }
            }
            Console.WriteLine("\n");
            Console.WriteLine("Select below options:");
            Console.WriteLine("\n");
            Console.WriteLine("\n 1: Deposit \n 2: Transfer \n 3: Return to mainmenu");

            string transaction = Console.ReadLine();

            switch (transaction)
            {
                case "1":
                    Transaction.Deposit();
                    break;
                case "2":
                    Transaction.TransferMoney();
                    break;
                case "3":
                    MainClass.ShowMainMenu();
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }

        }

        public static int accountNumberMarker = 1000;
        public static void CreateCustomer()
        {
            //Calling of Type of Account Class 
            TypeofAccount accountype = new TypeofAccount();
            Console.Clear();

            Console.WriteLine("--- Create New Customer ---");
            Console.Write("Please enter the Account Holder Name: ");
            string name = Console.ReadLine();

            //Account number icrement by +1
            int id = ++accountNumberMarker;

            //Instantiate a Customer object
            Customer customer = new Customer();
            customer.Name = name;

            //Readline reads in a string, thus we cast id to integer
            customer.ID = id;
            Bank.AllCustomers.Add(customer);

            for (int i = 1; i <= 2; i++)
            {
                accountype.TypeOfaccount = i;
                accountype.owner = customer.ID;
                TypeofAccount.TypeOfaccounts.Add(accountype);
            }
            MainClass.ShowMainMenu();
        }
    }
}
