﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExam1
{
    public class CheckingAccount : Account
    {
        public CheckingAccount(int owner, decimal balance) : base(owner, balance)
        {
        }

        //NOTE!!! variable for transferLlimit and method for to check tranferlimit, not
        //more then value of transferlimit the same day as the last transfer


        //Transfer limit daily set to max 5000

        //Check balance method
        public static void Checkbal()
        {
            if (Bank.AllCustomers.Count == 0)
            {
                string name = "NO Customers. Please create customers";
                Console.WriteLine(name);
                Console.ReadLine();
                MainClass.ShowMainMenu();
            }
            else
            {
                Console.Write("Please enter your account's ID: ");
                int id = Convert.ToInt32(Console.ReadLine());
                foreach (Customer myCustomer in Bank.AllCustomers)
                {
                    Movieticket movieticket = new Movieticket();
                    movieticket.SavingBonus(id);
                }
                   
                Console.ReadLine();
                MainClass.ShowMainMenu();

            }
        }


        //Implement methods from IAccountPlus interface
        //void IAccountPlus.SavingBonus()
        //{

        //    foreach (Customer myCustomer in Bank.AllCustomers)
        //    {
        //        //string date = myCustomer.dateString;
        //        //DateTime starttime = DateTime.Parse(date);
        //        DateTime date = myCustomer.dateString;
        //        DateTime starttime = date;
        //        DateTime expiry = starttime.AddDays(30);
        //        if (DateTime.Now > expiry)
        //        {
        //            Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n CheckingAccount Balance: " + myCustomer.CurrentBalance + "krona" + " You have earned a movie ticket");
        //            Console.ReadLine();
        //        }
        //        else
        //        {
        //            Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n CheckingAccount Balance: " + myCustomer.CurrentBalance + "krona");
        //        }
        //    }
        //}
    }
}
