﻿using System;

namespace BankExam1
{
    public class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }

        //public int TypeofAccount { get; set; }

        public DateTime dateString = new DateTime(2018,12,12);
       // public string dateString = DateTime.Now.ToString();
        public string TransactionSummary { get; set; }

        //public string TransactionSummary2 { get; set; }
        
        public float SavingBalance { get; set; }

        public float CurrentBalance { get; set; }

        //Default constructor
        public Customer()
        {
            SavingBalance = 5000;
            CurrentBalance = 0;
        }

        //public static void ShowAllCustomers()
        //{
        //    string acctype = "";
        //    Console.Clear();
        //    Console.WriteLine();
        //    Console.WriteLine("-----------");


        //    /*Checking if the users are present in the bank.*/

        //    if (Bank.AllCustomers.Count == 0)
        //    {
        //        string name = "NO Customers. Please create Customers";
        //        Console.WriteLine(name);
        //        Console.WriteLine("-----------");
        //        Console.WriteLine();
        //        Console.ReadLine();
        //        MainClass.ShowMainMenu();
        //    }

        //    /*For each loop is used to pick the elements one by one from array or Collection,
        //     in the loop we instantiate a empty bank object*/
        //    else
        //    {
        //        foreach (Customer myCustomer in Bank.AllCustomers)
        //        {
        //            Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n Saving Balance: " + myCustomer.SavingBalance + "krona" + "\n CheckingAccount Balance: " + myCustomer.CurrentBalance + "krona" + "\n MemberSince: " + myCustomer.dateString);
        //            for (int i = 1; i <= 2; i++)
        //            {
        //                if (i == 1)
        //                {
        //                    acctype = "Saving Account";
        //                }
        //                else
        //                {
        //                    acctype = "Current Account";
        //                }
        //                // Console.WriteLine("Type of account: " + i + "   AccountType: " + acctype);
        //            }

        //        }
        //    }
        //    Console.WriteLine("\n");
        //    Console.WriteLine("Select below options:");
        //    Console.WriteLine("\n");
        //    Console.WriteLine("\n 1: Deposit \n 2: Transfer \n 3: Return to mainmenu");

        //    string transaction = Console.ReadLine();

        //    switch (transaction)
        //    {
        //        case "1":
        //            Transaction.Deposit();
        //            break;
        //        case "2":
        //            Transaction.TransferMoney();
        //            break;
        //        case "3":
        //            MainClass.ShowMainMenu();
        //            break;
        //        default:
        //            Console.WriteLine("Invalid choice");
        //            break;
        //    }

        //}

        public static void GenerateAccountReport()
        {
            Transaction t = new Transaction();
            if (Transaction.TransactionSummary == "")
            {
                Console.WriteLine("No Transactions performed for the day");
            }
            else
            {
                foreach (Customer c in Bank.AllCustomers)
                {

                    Console.WriteLine("{0}", c.TransactionSummary);
                }
            }
            Console.ReadLine();
            MainClass.ShowMainMenu();
        }

        //Static accont number used for making account number
        //public static int accountNumberMarker = 1000;
        //public static void CreateCustomer()
        //{
        //    //Calling of Type of Account Class 
        //    TypeofAccount accountype = new TypeofAccount();
        //    Console.Clear();

        //    Console.WriteLine("--- Create New Customer ---");
        //    Console.Write("Please enter the Account Holder Name: ");
        //    string name = Console.ReadLine();

        //    //Account number icrement by +1
        //    int id = ++accountNumberMarker;

        //    //Instantiate a Customer object
        //    Customer customer = new Customer();
        //    customer.Name = name;

        //    //Readline reads in a string, thus we cast id to integer
        //    customer.ID = id;
        //    Bank.AllCustomers.Add(customer);

        //    for (int i = 1; i <= 2; i++)
        //    {
        //        accountype.TypeOfaccount = i;
        //        accountype.owner = customer.ID;
        //        TypeofAccount.TypeOfaccounts.Add(accountype);
        //    }
        //    MainClass.ShowMainMenu();
        //}
    }
}