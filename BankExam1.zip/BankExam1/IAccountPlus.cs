﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExam1
{
    interface IAccountPlus
    {
        void SavingBonus(int id);
    }

    /*Remove class Movieticket but use the method in the child account classes of
    Checking account and Saving account classes
         */
    public class Movieticket : Customer, IAccountPlus
    {
        public void SavingBonus(int id)
        {
            bool isidavailable = false;
            foreach (Customer myCustomer in Bank.AllCustomers)
            {
                if (id == myCustomer.ID)
                {
                    isidavailable = true;
                    //string date = myCustomer.dateString;
                    //DateTime starttime = DateTime.Parse(date);
                    DateTime date = myCustomer.dateString;
                    DateTime starttime = date;
                    DateTime expiry = starttime.AddDays(30);
                    if (DateTime.Now > expiry)
                    {
                        Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n CheckingAccount Balance: " + myCustomer.CurrentBalance + "krona" + " You have earned a movie ticket");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n CheckingAccount Balance: " + myCustomer.CurrentBalance + "krona");
                    }
                }
            }
            if (!isidavailable)
            {
                Console.WriteLine("No such details available. Please try with valid details");
                Console.ReadLine();
                Console.Clear();
                MainClass.ShowMainMenu();

            }
        }
    }
}
