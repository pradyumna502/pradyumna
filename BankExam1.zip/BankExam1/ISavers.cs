﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExam1
{
    interface ISavers
    {
        void BonusIntrest(int id =0);
    }

    /*Readme class Bonus can be removed, but the method can be utilised in the
    child account class of SavingAccount
         */
    public class Bonus : Customer, ISavers
    {

        public void BonusIntrest(int id)
        {
            bool isidavailable = false;
            foreach (Customer myCustomer in Bank.AllCustomers)
            {
                if (id == myCustomer.ID)
                {
                    isidavailable = true;
                    DateTime date = myCustomer.dateString;
                    DateTime starttime = date;
                    DateTime expiry = starttime.AddDays(30);
                    if (DateTime.Now < expiry)
                    {
                        Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n SavingAccount Balance: " + myCustomer.SavingBalance + "krona");
                        Console.ReadLine();
                        SavingsAccount.getuserdetails();
                    }
                    else
                    {
                        float rate = 5.0F, interest, total_amt;
                        interest = myCustomer.SavingBalance * rate / 100;
                        total_amt = myCustomer.SavingBalance + interest;
                        myCustomer.SavingBalance = total_amt;
                        Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n SavingAccount Balance: " + myCustomer.SavingBalance + "krona");
                        Console.ReadLine();

                        MainClass.ShowMainMenu();
                    }

                }
                

            }
            if(!isidavailable)
            {
                Console.WriteLine("No such details available. Please try with valid details");
                Console.ReadLine();
                Console.Clear();
                MainClass.ShowMainMenu();

            }
        }
    }
}