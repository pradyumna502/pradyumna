﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace BankExam1
{
    public class MainClass
    {

        public static void Main(string[] args)
        {
            ShowMainMenu();
        }

        public static void ShowMainMenu()
        {
            Customer customer = new Customer();
            if (Bank.AllCustomers.Count == 0)
            {
                Console.Clear();
                Console.WriteLine("Welcome to the Nordea Bank");
                Console.WriteLine("-------------------");
                Console.WriteLine("1: Create customer");
                Console.WriteLine("2: Show Customers");
                Console.WriteLine("3: Exit");
                Console.WriteLine("-------------------");
                string command = Console.ReadLine();

                switch (command)
                {
                    case "1":
                        Bank.CreateCustomer();
                        break;
                    case "2":
                        Bank.ShowAllCustomers();
                        break;
                    case "3":
                        Environment.Exit(-1);
                        break;

                    default:
                        Console.WriteLine("Invalid choice");
                        Console.ReadLine();
                        ShowMainMenu();
                        break;
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Welcome to the Nordea Bank");
                Console.WriteLine("-------------------");
                Console.WriteLine("1: Create customer");
                Console.WriteLine("2: Show Customers");
                Console.WriteLine("3: Savings Account Details");
                Console.WriteLine("4: Checking Account Balance");
                Console.WriteLine("5: ShowAllTransactions");
                Console.WriteLine("6: Exit");
                Console.WriteLine("-------------------");

                string command = Console.ReadLine();

                switch (command)
                {
                    case "1":
                        Bank.CreateCustomer();
                        break;
                    case "2":
                        Bank.ShowAllCustomers();
                        break;
                    case "3":
                        SavingsAccount.getuserdetails();
                        break;
                    case "4":
                        CheckingAccount.Checkbal();
                        break;
                    case "5":
                        Customer.GenerateAccountReport();
                        break;
                    case "6":
                        Environment.Exit(-1);
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
            }
        }





    }
}
