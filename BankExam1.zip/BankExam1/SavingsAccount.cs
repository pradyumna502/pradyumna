﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExam1
{
    public class SavingsAccount : Account
    {

        // Variable for intrest rate for the saving class. This is already set in BonusIntrest of ISavers

        double intrestRate;

        public double IntrestRate { get => intrestRate; set => intrestRate = value; }

        public SavingsAccount(int id, decimal newBalance) : base(id, newBalance) { }

        /* ???????: This method is used t get the valid on demand employee details,
         * from the Customer list */
        /*Provide account ID and get user details from Customer list for
         eligibility to get movie tickets?
         */
        public static void getuserdetails()
        {
            Console.Write("Please enter your account's ID: ");
            int id = Convert.ToInt32(Console.ReadLine());

            Bonus bonus = new Bonus();
            bonus.BonusIntrest(id);
        }

        //Implement methods from IAccountPlus interface
        //void IAccountPlus.SavingBonus()
        //{

        //    foreach (Customer myCustomer in Bank.AllCustomers)
        //    {
        //        //string date = myCustomer.dateString;
        //        //DateTime starttime = DateTime.Parse(date);
        //        DateTime date = myCustomer.dateString;
        //        DateTime starttime = date;
        //        DateTime expiry = starttime.AddDays(30);
        //        if (DateTime.Now > expiry)
        //        {
        //            Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n Balance: " + myCustomer.SavingBalance + "krona" + " You have earned a movie ticket");
        //            Console.ReadLine();
        //        }
        //        else
        //        {
        //            Console.WriteLine("ID: " + myCustomer.ID + "\n Name: " + myCustomer.Name + "\n Balance: " + myCustomer.SavingBalance + "krona");
        //        }
        //    }
        //}
    }
}
