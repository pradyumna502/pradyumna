﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BankExam1
{

    public class Transaction : Customer
    {
        Customer customer = new Customer();
        public static new string TransactionSummary = "";

        public static void Deposit()
        {

            Console.Clear();
            Console.WriteLine("--- Deposit Money ---");
            Console.Write("Enter the id of the customer: ");
            string customerId = Console.ReadLine();
            Console.Write("Enter the amount to deposit: ");
            string amount = Console.ReadLine();
            int theCustomerId = int.Parse(customerId);
            //Create object with default value is null, if Customer not found, the value is null
            Customer myFoundCustomer = null;

            /* c is local object in the argument, if argument is same as in the customer list*/
            foreach (Customer c in Bank.AllCustomers)
            {
                if (c.ID == theCustomerId)
                {
                    myFoundCustomer = c;
                    Console.WriteLine(" Sucessfully Amount Deposited to your account. \n");

                    TransactionSummary = string.Format("{0}\n Deposit:{1} \t from CustomerID:{2} \t To CustomerID:{3} \t To Account Type:{4} ",
                                          TransactionSummary, amount +  "krona", theCustomerId, theCustomerId,"Checking Account");

                    myFoundCustomer.TransactionSummary = TransactionSummary;

                    Console.WriteLine("Transcation TYPE: {0}, \n DATE:{1}, \n AMOUNT:{2}, \n TO ACCOUNT Type: {3}", "Deposit", DateTime.Now.ToString(), amount + "krona", "Checking Account");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Invalid Details");
                    Console.ReadLine();

                }

            }

            if (myFoundCustomer != null)
            {
                myFoundCustomer.CurrentBalance += float.Parse(amount);

            }
            MainClass.ShowMainMenu();
        }
        public static void TransferMoney()
        {

            float amount = 0;

            if (Bank.AllCustomers.Count > 1)
            {
                Console.Clear();
                Console.WriteLine("--- Transfer Money ---");

                Console.Write("Please enter your account ID: ");
                string id = Console.ReadLine();
                Console.Write("Please enter the id of the person you would like to transfer funds to: ");
                string id2 = Console.ReadLine();
                int theCustomerId = Convert.ToInt32(id);
                int theCustomertodeposit = Convert.ToInt32(id2);
                if (theCustomerId == theCustomertodeposit)
                {
                    Console.Write("Enter the amount of funds you would like to transfer: ");
                    amount = float.Parse(Console.ReadLine());

                    Customer c1 = null, c2 = null;

                    foreach (Customer c in Bank.AllCustomers)
                    {

                        if (c.ID == theCustomerId)
                        {
                            c1 = c;
                        }
                    }

                    foreach (Customer c in Bank.AllCustomers)
                    {
                        if (c.ID == theCustomertodeposit)
                        {
                            c2 = c;
                        }
                    }
                    if ((c1.CurrentBalance > 0 && c1.CurrentBalance >= amount))
                    {

                        c1.CurrentBalance = c1.CurrentBalance - amount;
                        c2.SavingBalance = c2.SavingBalance + amount;

                        TransactionSummary = string.Format("{0}\n Transfer: {1} \t From CustomerID: {2} To CustomerID: {3}\t To Account Type:{4} ",
                   TransactionSummary, amount + "krona", theCustomerId, theCustomertodeposit,"Saving Account");

                        c1.TransactionSummary = TransactionSummary;

                        Console.WriteLine("Transcation TYPE: {0}, \n DATE:{1}, \n AMOUNT:{2}, \n From ACCOUNT Number: {3}, \n TO ACCOUNT Number: {4}", "Transfer", DateTime.Now.ToString(), amount + "krona", theCustomerId, theCustomertodeposit);
                        Console.ReadLine();

                    }

                    else
                    {
                        Console.WriteLine("Insufficient Balance");
                        Console.WriteLine("Your Current Balance is: {0}", c1.CurrentBalance + "krona");
                        Console.ReadLine();
                    }
                }
                else if (theCustomerId != theCustomertodeposit)
                {
                    Console.Write("Enter the amount of funds you would like to transfer: ");
                    amount = float.Parse(Console.ReadLine());

                    Customer c1 = null, c2 = null;

                    foreach (Customer c in Bank.AllCustomers)
                    {

                        if (c.ID == theCustomerId)
                        {
                            c1 = c;
                        }
                    }

                    foreach (Customer c in Bank.AllCustomers)
                    {
                        if (c.ID == theCustomertodeposit)
                        {
                            c2 = c;
                        }
                    }
                    if ((c1.CurrentBalance > 0 && c1.CurrentBalance >= amount))
                    {

                        c1.CurrentBalance = c1.CurrentBalance - amount;
                        c2.CurrentBalance = c2.CurrentBalance + amount;
                        TransactionSummary = string.Format("{0}\n Transfer: {1} \t From CustomerID: {2} To CustomerID: {3} \t To Account Type:{4}",
                   TransactionSummary, amount + "krona", theCustomerId, theCustomertodeposit,"Checking Account");

                        c1.TransactionSummary = TransactionSummary;

                        Console.WriteLine("Transcation TYPE: {0}, \n DATE:{1}, \n AMOUNT:{2}, \n From ACCOUNT Number: {3}, \n TO ACCOUNT Number: {4}", "Transfer", DateTime.Now.ToString(), amount +"krona", theCustomerId, theCustomertodeposit);
                        Console.ReadLine();

                    }

                    else
                    {
                        Console.WriteLine("Insufficient Balance");
                        Console.WriteLine("Your Current Balance is: {0}", c1.CurrentBalance + "krona");
                        Console.ReadLine();
                    }
                }

                Bank.ShowAllCustomers();

            }
            else
            {
                Console.WriteLine("No other customers available to transfer");
                Console.ReadLine();
                Bank.ShowAllCustomers();
            }

        }

    }
}
