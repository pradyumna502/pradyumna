﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExam1
{
    public class TypeofAccount
    {

        public static List<TypeofAccount> accounts = new List<TypeofAccount>();

        public int TypeOfaccount { get; set; }
        public int owner { get; set; }

        public static List<TypeofAccount> TypeOfaccounts
        {
            get { return accounts; }
        }
        public TypeofAccount()
        {
            accounts = new List<TypeofAccount>();
        }


    }
}
