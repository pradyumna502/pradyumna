﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> Numbers = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private double total1 = 0;
        private double tob = 0;
        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool multiplyButtonClicked = false;
        bool divideButtonClicked = false;
        bool squareButtonClicked = false;


        private void btnClearEntry_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text = "0";
            labelCurrentOperation.Content = "";
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text = "0";
            labelCurrentOperation.Content = "";

        }

        private void btnEquals_Click(object sender, RoutedEventArgs e)
        {
            if (plusButtonClicked == true)
            {
                tob = total1 + double.Parse(textBox_Result.Text);
                labelCurrentOperation.Content = total1 + "+" + double.Parse(textBox_Result.Text);
                textBox_Result.Text = tob.ToString();
                total1 = 0;
            }
            else if (minusButtonClicked == true)
            {
                tob = total1 - double.Parse(textBox_Result.Text);
                labelCurrentOperation.Content = total1 + "-" + double.Parse(textBox_Result.Text);
                textBox_Result.Text = tob.ToString();
                total1 = 0;
            }
            else if (multiplyButtonClicked == true)
            {
                tob = total1 * double.Parse(textBox_Result.Text);
                labelCurrentOperation.Content = total1 + "*" + double.Parse(textBox_Result.Text);
                textBox_Result.Text = tob.ToString();
                total1 = 0;
            }
            else if (divideButtonClicked == true)
            {
                tob = total1 / double.Parse(textBox_Result.Text);
                labelCurrentOperation.Content = total1 + "/" + double.Parse(textBox_Result.Text);
                textBox_Result.Text = tob.ToString();
                total1 = 0;
            }

        }

        private void btnBackSpace_Click(object sender, RoutedEventArgs e)
        {
            int i = textBox_Result.Text.Length;
            textBox_Result.Text = textBox_Result.Text.Substring(0, textBox_Result.Text.Length - 1);

        }

        private void btnPositiveNegative_Click(object sender, RoutedEventArgs e)
        {
            if (textBox_Result.Text.StartsWith("-"))
            {
                //It's negative now, so strip the `-` sign to make it positive
                textBox_Result.Text = textBox_Result.Text.Substring(1);
            }
            else if (!string.IsNullOrEmpty(textBox_Result.Text) && decimal.Parse(textBox_Result.Text) != 0)
            {
                //It's positive now, so prefix the value with the `-` sign to make it negative
                textBox_Result.Text = "-" + textBox_Result.Text;
            }
        }

        private void btn7_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "7";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "8";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "9";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "4";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "5";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "6";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "1";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "2";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "3";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "0";
            labelCurrentOperation.Content = textBox_Result.Text;
            Numbers.Add(textBox_Result.Text);
        }

        private void btnPlus_Click(object sender, RoutedEventArgs e)
        {
            total1 += double.Parse(textBox_Result.Text);
            labelCurrentOperation.Content = textBox_Result.Text + "+";
            textBox_Result.Text = "";

            plusButtonClicked = true;
            minusButtonClicked = false;
            multiplyButtonClicked = false;
            divideButtonClicked = false;
            squareButtonClicked = false;
        }

        private void btnMinus_Click(object sender, RoutedEventArgs e)
        {
            total1 += double.Parse(textBox_Result.Text);
            labelCurrentOperation.Content = textBox_Result.Text + "-";
            textBox_Result.Text = "";

            plusButtonClicked = false;
            minusButtonClicked = true;
            multiplyButtonClicked = false;
            divideButtonClicked = false;
            squareButtonClicked = false;
        }

        private void btnTimes_Click(object sender, RoutedEventArgs e)
        {
            total1 += double.Parse(textBox_Result.Text);
            labelCurrentOperation.Content = textBox_Result.Text + "*";
            textBox_Result.Text = "";

            plusButtonClicked = false;
            minusButtonClicked = false;
            multiplyButtonClicked = true;
            divideButtonClicked = false;
            squareButtonClicked = false;
        }

        private void btnDivide_Click(object sender, RoutedEventArgs e)
        {
            total1 += double.Parse(textBox_Result.Text);
            labelCurrentOperation.Content = textBox_Result.Text + "/";
            textBox_Result.Text = "";

            plusButtonClicked = false;
            minusButtonClicked = false;
            multiplyButtonClicked = false;
            divideButtonClicked = true;
            squareButtonClicked = false;
        }

        private void btnSquare_Click(object sender, RoutedEventArgs e)
        {
            if (textBox_Result.Text != "0")
            {
                total1 = Math.Round(Math.Sqrt(Convert.ToDouble(textBox_Result.Text)));
                labelCurrentOperation.Content = "SQRT" + "(" + (textBox_Result.Text) + ")";
                textBox_Result.Text = Convert.ToString(total1);
            }
            else
            {
                MessageBox.Show("InValid Text. Please provide Text");
            }
        }

        private void btnDecimal_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += ",";
        }

        private void OpenBrase_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += "(";
            string s = textBox_Result.Text;

            Numbers.Add("(");
            if (s == "(")
            {
                textBox_Result.Text = "";
            }
            string combindedString = string.Join(",", Numbers.ToArray());
            string lasttwochars = combindedString.Substring(combindedString.Length - 3);
            int count = lasttwochars.Where(x => x == '(').Count();
            if (count >= 2)
            {
                Numbers.RemoveAt(Numbers.Count - 1);
            }
            else
            {
                if (s == "(")
                {
                    textBox_Result.Text = "";
                }
            }

        }
        private void CloseBrase_Click(object sender, RoutedEventArgs e)
        {
            textBox_Result.Text += ")";
            Numbers.Add(")");
            string s = textBox_Result.Text;
            int pos = s.IndexOf(")");
            string sa = s.Remove(pos);
            string lastchar = s.Substring(s.Length - 1, 1);
            if (lastchar == ")")
            {
                textBox_Result.Text = "";
            }
            string combindedString = string.Join(",", Numbers.ToArray());
            string lasttwochars = combindedString.Substring(combindedString.Length - 3);
            int count = lasttwochars.Where(x => x == ')').Count();
            if (count >= 2)
            {
                Numbers.RemoveAt(Numbers.Count - 1);
            }
            else
            {
                if (lastchar == ")")
                {
                    textBox_Result.Text = "";
                }
            }

        }
    }
}
