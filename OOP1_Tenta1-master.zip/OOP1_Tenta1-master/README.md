# Tenta1_OOP1
## Fr�gor  
1.Read two numbers into a fraction, If any of the read numbers are negative, convert it to a positive number of the same numeric value  
2.Load five numbers into an array. Print the number or numbers larger than the first number.  
3. Create a function with three arguments, the arguments should only receive positive integers.  
Print True if the arguments are between 20 and 50 or False if not. Create a number of examples that show both outcomes.  
4. Create a function that receives three numbers. Then check if y is greater than x and z is greater than y.  
The arguments must contain both negative and positive integers.  
5. Create a program that shows the largest number of two. If both numbers are equal, return 0.  
But if both numbers have the same residual numbers when they are divided by 7, return the smaller of the two numbers.  
6. Create an array with five indexes, they should be able to take in both positive and negative integers. Then add up and show the sum.  
7. Create an array with a length of four integers, then create a new array where the contents of the first array are filled in reverse order and printed.  
8. Create an array with a length of five integers, both negative and positive.  
Then create a new array where the contents of the middle index of the first array are filled in all the new array indexes and printed.  
9. Create two arrays of both positive and negative integers. Then return the array that has the largest sum of its indexes.  
10. Based on the calculator you have created before, or the one I have posted, create a function in the calculator that takes into account the operator precedence in mathematics  
Tex, the number series 5+ (2/3 * 2) should result in 6.333 and note 4.666.  
You can add brackets buttons to the calculator or just print the answer in the window directly.
