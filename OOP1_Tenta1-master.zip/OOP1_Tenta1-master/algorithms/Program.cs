﻿using System;

namespace Algorithmer
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine();
            menu.Menus();
        }
    }
}
