﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Algorithmer
{
    public static class Question1
    {
        public static int a, b;
        public static int[] elements = new int[2];
        public static void Positive()
        {
            Console.WriteLine("Question 1:");
            Console.WriteLine("Enter Numerator: ");
            elements[0] = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Denominator: ");
            elements[1] = int.Parse(Console.ReadLine());
            //For Numerator
            if (elements[0] < 0)
            {
                a = elements[0] * -1;
            }
            else if (elements[0] > 0)
            {
                a = elements[0] * 1;
            }
            //For Denominator
            if (elements[1] < 0)
            {
                b = elements[1] * -1;
            }
            else if (elements[1] > 0)
            {
                b = elements[1] * 1;
            }
            Console.WriteLine("Input values are:{0}/{1}", elements[0], elements[1]);
            Console.WriteLine("Positive numbers are:{0}/{1}", a, b);
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            menu.Menus();
        }
    }
}

