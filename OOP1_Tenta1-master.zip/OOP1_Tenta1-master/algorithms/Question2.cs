﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Algorithmer
{
    class Question2
    {
        public static void LargerThanFirst()
        {
            Console.WriteLine("Question 2:");
            int[] array = new int[5];
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine("Enter element" + (i + 1));
                array[i] = int.Parse(Console.ReadLine());
            }

            foreach (var numbers in array)
            {
                if (numbers > array[0])
                {
                    Console.WriteLine("Numbers bigger than the first number: \n");
                    Console.WriteLine(+numbers);
                }
                else
                {
                    Console.WriteLine("First element should be smaller than any other element in array");
                    Console.ReadKey();
                    Console.Clear();

                }
                LargerThanFirst();
            }

            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            menu.Menus();
        }
    }
}
