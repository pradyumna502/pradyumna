﻿using System;
using System.Collections.Generic;
using System.Text;

/*
 Create a function with three arguments, the arguments should only receive positive integers.  
Print True if the arguments are between 20 and 50 or False if not. Create a number of examples that show both outcomes.
Forgot to do outputh with PrintLine.
*/

namespace Algorithmer
{
    public static class Question3
    {
        public static int a, b, c;
        public static bool test(int x, int y, int z)
        {
            Question3.a = x;
            Question3.b = y;
            Question3.c = z;
            return (x >= 20 && x <= 50) || (y >= 20 && y <= 50) || (z >= 20 && z <= 50);
        }

        public static void RunQuestion3()
        {
            Console.WriteLine("Question 3");
            Console.WriteLine("Case1:{0}",test(11, 20, 12));
            Console.WriteLine("Case1:{0},{1},{2}", + Question3.a, + Question3.b, + Question3.c);
            Console.WriteLine();
            Console.WriteLine("Case2:{0}",test(30, 30, 17));
            Console.WriteLine("Case2:{0},{1},{2}",  Question3.a,  Question3.b,  Question3.c);
            Console.WriteLine();
            Console.WriteLine("Case3:{0}", test(25, 35, 50));
            Console.WriteLine("Case3:{0},{1},{2}",  Question3.a,  Question3.b,  Question3.c);
            Console.WriteLine();
            Console.WriteLine("Case4:{0}", test(15, 12, 8));
            Console.WriteLine("Case4:{0},{1},{2}",  Question3.a,  Question3.b,  Question3.c);
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            menu.Menus();
        }
    }

}
