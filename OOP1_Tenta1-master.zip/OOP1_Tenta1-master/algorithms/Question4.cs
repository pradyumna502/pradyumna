﻿using System;
using System.Collections.Generic;
using System.Text;

/*
 Create a function that receives three numbers. Then check if y is greater than x and z is greater than y.
The arguments must contain both negative and positive integers.
*/

namespace Algorithmer
{
    public static class Question4
    {
        public static bool test(int x, int y, int z)
        {
            return x < y && y < z;
        }

        public static void RunQuestion4()
        {
            Console.WriteLine("Question 4:");
            Console.WriteLine(test(1, 2, 3));
            Console.WriteLine(test(4, 5, 6));
            Console.WriteLine(test(-1, 1, 0));
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            menu.Menus();
        }
    }
}
