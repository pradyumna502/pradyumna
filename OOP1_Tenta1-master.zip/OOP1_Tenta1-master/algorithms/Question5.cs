﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Algorithmer
{
    class Question5
    {
        public static void RunQuestion5()
        {
            Console.WriteLine("Question 5:");
            Console.Write("Enter a number: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Enter another number: ");
            int b = int.Parse(Console.ReadLine());

            if (a > b && a % 7 == b % 7)
            {
                Console.WriteLine(+a+ "is bigger than" +b+ "but" +b+ "is smaller as per the residual value");
            }
            if (a % 7 == b % 7 && b > a)
            {
                Console.WriteLine(+b + "is bigger than" + a + "but" + a + "is smaller as per the residual value");
            }
            if (a == b)
            {
                Console.WriteLine("Result: 0");
            }
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            menu.Menus();
        }
    }
}
