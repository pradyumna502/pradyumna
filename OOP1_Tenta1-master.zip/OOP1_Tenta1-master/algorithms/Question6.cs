﻿using System;
using System.Collections.Generic;
using System.Text;

/*
 Create an array with five indexes, they should be able to take in both positive and negative integers. 
 Then add up and show the sum.
 */

namespace Algorithmer
{
    public static class Question6
    {
        public static int a, b, c,d,e;
        public static int test(int[] a1)
        {
            Question6.a = a1[0];
            Question6.b = a1[1];
            Question6.c = a1[2];
            Question6.d = a1[3];
            Question6.e = a1[4];
            return a1[0] + a1[1] + a1[2] + a1[3] + a1[4];
        }

        public static void RunQuestion6()
        {
            Console.WriteLine("Question 6:");
            
            Console.WriteLine("Sum of all Positive Integers:{0}",+test(new[] { 10, 20, 30, 40, 50 }));
            Console.WriteLine("Positive Integers:{0},{1},{2},{3},{4}", +Question6.a, +Question6.b, +Question6.c, +Question6.d, +Question6.e);
            Console.WriteLine();
           
            Console.WriteLine("Sum of all Positive and Negative Integers:{0}",test(new[] { 10, 20, -30, -40, 50 }));
            Console.WriteLine("Positive & Negative Integers:{0},{1},{2},{3},{4}", +Question6.a, +Question6.b, +Question6.c, +Question6.d, +Question6.e);
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            menu.Menus();
        }
    }
}
