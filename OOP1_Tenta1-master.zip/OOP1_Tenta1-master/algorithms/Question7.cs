﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Algorithmer
{
    public static class Question7
    {
        public static void RunQuestion7()
        {
            Console.WriteLine("Question 7:");
            int[] a = new int[4];

            for (int i = 0; i < 4; i++)
            {
                Console.Write("Enter a number: ");
                int userInput = int.Parse(Console.ReadLine());
                a[i] = userInput;
            }

            //the new array
            int[] newArray = new int[4];
            //store old array into new
            newArray = a;
            //reversing the order
            Array.Reverse(newArray);

            //printing out the new array
            foreach (var num in newArray)
            {
                Console.WriteLine($"{num}");
            }

            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            menu.Menus();
        }
    }
}
