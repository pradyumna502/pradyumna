﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Algorithmer
{
    class Question8
    {
        public static void RunQuestion8()
        {
            Console.WriteLine("Question 8:");
            int[] arr = new int[5] { 99, -20, 30, 56, -9 };
            int[] arr2 = new int[5];
            Console.WriteLine("Printing out the array!");
            for (int i = 0; i < 5; i++)
            {
                arr2[i] = arr[2];
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Old Array Values:{0}", +arr[i]);
                Console.WriteLine("New Array Values:{0}", +arr2[i]);
                Console.WriteLine();
            }

            Console.ReadKey();

        }
    }
}
