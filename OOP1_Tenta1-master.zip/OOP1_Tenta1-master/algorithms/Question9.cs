﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Algorithmer
{
    public static class Question9
    {
        public static int[] test(int[] nums1, int[] nums2)
        {
            return nums1[0] + nums1[1] + nums1[2] >= nums2[0] + nums2[1] + nums2[2] ? nums1 : nums2;
        }

        public static void RunQuestion9()
        {
            int[] item = test(new[] { 10, 20, -30 }, new[] { 10, 20, 30 });
            Console.Write("Larger array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            menu.Menus();
        }
    }
}
