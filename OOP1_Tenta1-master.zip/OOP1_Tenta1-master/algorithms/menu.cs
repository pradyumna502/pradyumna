﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Algorithmer
{
    public static class menu
    {

        public static void Menus()
        {
            bool done = true;

            do
            {
                Console.WriteLine("Exam - 1 Questions and their solutions");
                Console.WriteLine("Question (1)");
                Console.WriteLine("Question (2)");
                Console.WriteLine("Question (3)");
                Console.WriteLine("Question (4)");
                Console.WriteLine("Question (5)");
                Console.WriteLine("Question (6)");
                Console.WriteLine("Question (7)");
                Console.WriteLine("Question (8)");
                Console.WriteLine("Question (9)");
                Console.WriteLine("Exit (e)");

                string questions = Console.ReadLine();

                switch (questions)
                {
                    case "0":
                        done = true;
                        break;
                    case "1":
                        Console.Clear();
                        Question1.Positive();
                        break;
                    case "2":
                        Console.Clear();
                        Question2.LargerThanFirst();
                        break;
                    case "3":
                        Console.Clear();
                        Question3.RunQuestion3();
                        break;
                    case "4":
                        Console.Clear();
                        Question4.RunQuestion4();
                        break;
                    case "5":
                        Console.Clear();
                        Question5.RunQuestion5();
                        break;
                    case "6":
                        Console.Clear();
                        Question6.RunQuestion6();
                        break;
                    case "7":
                        Console.Clear();
                        Question7.RunQuestion7();
                        break;
                    case "8":
                        Console.Clear();
                        Question8.RunQuestion8();
                        break;
                    case "9":
                        Console.Clear();
                        Question9.RunQuestion9();
                        break;
                    case "e":
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid choice");
                        Console.ReadLine();
                        Console.Clear();
                        menu.Menus();
                        break;
                }
                Console.ReadKey();
                Console.Clear();
                menu.Menus();

            } while (!done);

        }
    }
}
