﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace BMI_Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static string gender;

        public MainWindow()
        {
            InitializeComponent();

        }
        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            int kg, m;
            string gen1 = "Male";
            string gen2 = "Female";
            kg = int.Parse(txtweight.Text);
            m = int.Parse(txtheight.Text);
            double BMI = kg / Math.Pow(m / 100.0, 2);

            if ((BMI < 19) && (gender == gen2))
            {
                txtresult.Text = "Weight:" + txtweight.Text + "\n" + "Height:" + txtheight.Text + "\n" + "Gender:" + gen2 + "\n" + "Underweight";
            }

            if (BMI >= 19 & BMI <= 24)
            {
                txtresult.Text = "Weight:" + txtweight.Text + "\n" + "Height:" + txtheight.Text + "Gender:" + gen2 + "\n" + "Normal";
            }
            if ((BMI > 24) && (gender == gen2))
            {

                txtresult.Text = "Weight:" + txtweight.Text + "\n" + "Height:" + txtheight.Text + "\n" + "Gender:" + gen2 + "\n" + "Overweight";
            }
            if ((BMI < 20) && (gender == gen1))
            {
                txtresult.Text = "Weight:" + txtweight.Text + "\n" + "Height:" + txtheight.Text + "\n" + "Gender:" + gen1 + "\n" + "Underweight";
            }
            if ((BMI >= 20) && (gender == gen1))
            {
                txtresult.Text = "Weight:" + txtweight.Text + "\n" + "Height:" + txtheight.Text + "\n" + "Gender:" + gen1 + "\n" + "Normal";
            }
            if ((BMI > 25) && (gender == gen1))
            {

                txtresult.Text = "Weight:" + txtweight.Text + "\n" + "Height:" + txtheight.Text + "\n" + "Gender:" + gen1 + "\n" + "Overweight";
            }
            txtheight.Text = "";
            txtweight.Text = "";
        }

        private void HandleCheck(object sender, RoutedEventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            gender = Convert.ToString(rb.Content);
        }
    }
}
