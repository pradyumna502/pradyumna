# Tenta1_OOP2
## Algoritmer  
1.Check two given integers, and return true if one of them is 30 or if their sum is 30.  
2.Write a C# Sharp program to check if two given non-negative integers have the same last digit.  
3. Write a C# Sharp program to check a specified number is present in a given array of integers with 4 indexes.   
Give a minimum of three arrays.   
4. Write a C# Sharp program to count the number of two 5's are next to each other in an array of integers.   
Also count the situation where the second 5 is actually a 6. Create at least three arrays.  
5. Write a C# Sharp program to compute the sum of the two given integers. If the sum is in the range 10..20 inclusive return 30.    
Create at least four arrays.   
6. Write a C# Sharp program to convert the last 3 characters of a given string in upper case.   
If the length of the string has less than 3 then uppercase all the characters.   
Create at least four examples and at least one of them with less then three characters.  
7. Write a C# Sharp program to check whether the sequence of numbers 1, 2, 3 appears in a given array of integers somewhere.  
Create at least thre examples.  
8. Write a C# Sharp program to find out the maximum element between the first or last element in a given array of integers (length 4),  
replace all elements with maximum element.    
9. Write a C# Sharp program to create a new list from a given list of integers where each element is multiplied by 3.  
  
## BMI Calculator  
10. Creata a wpf C# application to calculate your BMI index.  
The GUI has to take in weight, height and gender.    
The output should show the BMI and status of "Underweight", "Normal" or "Overweight" based upon the inputs.  
To calculate BMI given values are:  
	1. Gender  
	2. Height  
	3. Weight  
	4. The formula is:  
		1. Formula: **weight (kg) / [height (m)]2**  
			1. Remember to use proper dataypes.    
			2. Remember to use operator presdence.    
	5. If BMI is below 19 and gender is female, show "Underweight"  
	6. If BMI is larger or equal to 19 and BMI is smaller or eqaual to 24 and gender is female, show "Normal"  
	7. If BMI is larger then 24 and gender is female, show "Overweight".   
	8. If BMI is below 20 and gender is male, show "Underweight"  
	9. If BMI is larger or equal to 20 and BMI is smaller or eqaual to 25 and gender is male, show "Normal"  
	10. If BMI is larger then 25 and gender is male, show "Overweight"  