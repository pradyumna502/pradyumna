﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Algorithmer
{
    public static class Menu
    {

        public static void Menus()
        {
            bool done = true;

            do
            {
                Console.WriteLine("Question1 (1)");
                Console.WriteLine("Question2 (2)");
                Console.WriteLine("Question3 (3)");
                Console.WriteLine("Question4 (4)");
                Console.WriteLine("Question5 (5)");
                Console.WriteLine("Question6 (6)");
                Console.WriteLine("Question7 (7)");
                Console.WriteLine("Question8 (8)");
                Console.WriteLine("Question9 (9)");
                Console.WriteLine("Exit (e)");

                string questions = Console.ReadLine();

                switch (questions)
                {

                    case "0":
                        done = true;
                        break;
                    case "1":
                        algorithms.Question1.RunQuestion1();
                        break;
                    case "2":
                        algorithms.Question2.RunQuestion2();
                        break;
                    case "3":
                        Console.Clear();
                        algorithms.Question3.RunQuestion3();
                        break;
                    case "4":
                        Console.Clear();
                        algorithms.Question4.RunQuestion4();
                        break;
                    case "5":
                        Console.Clear();
                        algorithms.Question5.RunQuestion5();
                        break;
                    case "6":
                        Console.Clear();
                        algorithms.Question6.RunQuestion6();
                        break;
                    case "7":
                        Console.Clear();
                        algorithms.Question7.RunQuestion7();
                        break;
                    case "8":
                        Console.Clear();
                        algorithms.Question8.RunQuestion8();
                        break;
                    case "9":
                        Console.Clear();
                        algorithms.Question9.RunQuestion9();
                        break;
                    case "e":
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid choice");
                        Console.ReadLine();
                        break;
                }
                Console.ReadKey();
                Console.Clear();

            } while (!done);

        }
    }
}
