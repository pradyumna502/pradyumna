﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algorithms
{
    public static class Question1
    {
        public static bool test(int x, int y)
        {
            return x == 30 || y == 30 || (x + y == 30);
        }

        public static void RunQuestion1()
        {
            Console.WriteLine(test(30, 0));
            Console.WriteLine(test(25, 5));
            Console.WriteLine(test(20, 30));
            Console.WriteLine(test(20, 25));
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            Algorithmer.Menu.Menus();
        }
    }
}
