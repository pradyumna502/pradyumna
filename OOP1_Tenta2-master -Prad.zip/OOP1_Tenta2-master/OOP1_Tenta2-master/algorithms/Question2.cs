﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algorithms
{
    public static class Question2
    {
        public static bool test(int x, int y)
        {
            return Math.Abs(x % 10) == Math.Abs(y % 10);
        }

        public static void RunQuestion2()
        {
            Console.WriteLine(test(123, 456));
            Console.WriteLine(test(12, 512));
            Console.WriteLine(test(7, 87));
            Console.WriteLine(test(12, 45));
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            Algorithmer.Menu.Menus();
        }
    }
}
