﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algorithms
{
    public static class Question8
    {
        public static int[] test(int[] nums)
        {
            int max = nums.Max();

            return new int[] { max, max, max, max };
        }

        public static void RunQuestion8()
        {
            int[] item = test(new[] { 10, 20, -30, -40 });

            Console.Write("New array: ");

            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            Algorithmer.Menu.Menus();
        }
    }
}
