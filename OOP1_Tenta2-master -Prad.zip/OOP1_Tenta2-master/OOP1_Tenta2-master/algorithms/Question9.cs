﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algorithms
{
    public static class Question9
    {
        public static List<int> test(List<int> nums)
        {
            IEnumerable<int> doubled = nums.Select(x => x *= 3);
            return doubled.ToList<int>();
        }

        public static void RunQuestion9()
        {
            List<int> mylist = test(new List<int>(new int[] { 1, 2, 3, 4 }));
            foreach (var i in mylist)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            Algorithmer.Menu.Menus();
        }
    }
}
