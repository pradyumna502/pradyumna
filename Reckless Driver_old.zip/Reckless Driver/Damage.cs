﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver {
    public static class Damage {
        public static class SideObject {
            public const int FIREHYDRANT = 10;
            public const int POSTBOX = 5;
        }
        public static class TrafficCar {
            public const int SEDAN = 20;
            public const int VAN = 30;
        }
    }
    public static class Cash {
        public static class SideObject {
            public const int FIREHYDRANT = 50;
            public const int POSTBOX = 70;
        }
        public static class TrafficCar {
            public const int SEDAN = 100;
            public const int VAN = 150;
        }
    }
}
