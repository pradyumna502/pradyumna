﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Reckless_Driver {
    /*
    class GameManager {
        private float playerCash;
        public float PlayerCash {
            get {
                return playerCash;
            }
        }
        public void AddPlayerCash(float amount) {
            playerCash += amount;
        }
        ObjectPool sideObjectsPool;
        ObjectPool trafficCarsPool;
        private static GameManager instance = new GameManager();
        public static GameManager Instance {
            get { return instance; }
        }
        public void GameEnd() {
            //Show UI to restart or go to main menu
            Console.WriteLine("Cash earned : ${0}", playerCash);
            Console.WriteLine("Game has ended. What do you want to do?");
            Console.WriteLine("1. Restart");
            Console.WriteLine("2. Main Menu");
            Console.Write("? ");
            ConsoleKeyInfo info = Console.ReadKey();
            switch (info.Key) {
                case ConsoleKey.D1:
                    OnNewGame();
                    break;
                case ConsoleKey.D2:
                    break;
            }
            
        }
        public void OnNewGame() {
            //Choose player car
            Player player = new Player() {
                Name = "Player"
            };
            PlayerSedan ps = new PlayerSedan("Sedan", 5, 40, 5);
            player.Car = ps;

            //GenerateGameObjects();
            Thread th = new Thread(CreateGameObjects);
            th.Start();
            Random r = new Random();
            //List<GameObject> sideList = new List<GameObject>();
            //List<GameObject> trafficCarList = new List<GameObject>();
            ActiveObjects sideList = new ActiveObjects("Side Objects");
            ActiveObjects trafficCarList = new ActiveObjects("Traffic Cars");
            while (player.IsAlive) {
                Thread.Sleep(1000);
                Console.Clear();

                //Remove oldest game object
                Remove(sideList);
                Remove(trafficCarList);
               

                //Generate traffic and side objects
                sideList.Add(sideObjectsPool.GetPooledObject());

                trafficCarList.Add(trafficCarsPool.GetPooledObject());

                sideList.Display();
                trafficCarList.Display();

                //Player is driving the car
                Drive();

                //Player smashes into random object (car or side object)
                switch (r.Next(0,2)) {
                    case 0://Collide with side object
                        sideList.Collide(player);
                        
                        break;
                    case 1://Collide with traffic car
                        trafficCarList.Collide(player);
                        break;
                }
                //Return the object to the pool
                //Calculate damage
                //Accumulate cash
                //Repeat until health > 0 
            }
            GameEnd();
        }
        private void Drive() {
            Console.WriteLine("\nPlayer is driving");
            for (int i = 0; i < 10; ++i) {
                Thread.Sleep(200);
                Console.Write(".");
            }
            Console.WriteLine("");
        }
        private void Remove(ActiveObjects activeObj) {
            const int MAX_OBJECTS = 6;
            if (activeObj.GetCount() >= MAX_OBJECTS) {
                //Remove the oldest object
                activeObj.RemoveOldest();
            }
        }
        private void CreateGameObjects() {
            sideObjectsPool = new ObjectPool(() => {
                return SideObject.Create();
            });
            trafficCarsPool = new ObjectPool(() => {
                return TrafficCar.Create();
            });
            //sideObjects[0].AddObject(new FireHydrant(Damage.SideObject.FIREHYDRANT, Cash.SideObject.FIREHYDRANT));

            //trafficCars = new ObjectPoolManager();
            //trafficCars.AddObject(new Sedan());
            //trafficCars.AddObject(new Van());
        }
        private void GameLoop() {
            
        }
    }
    class ActiveObjects {
        List<GameObject> active = new List<GameObject>();
        public void Add(GameObject go) {
            active.Add(go);
        }
        public string GetName() {
            return objectName;
        }
        private string objectName;
        public ActiveObjects(string name) {
            objectName = name;
        }
        public void RemoveOldest() {
            active[0].Enabled = false;
            active.RemoveAt(0);
        }
        public int GetCount() {
            return active.Count;
        }
        public void Collide(Player player) {
            Random r = new Random();
            GameObject obj = active[r.Next(active.Count)];
            obj.OnCollision(player);
            if (!player.IsAlive)
                return;
            //Remove this object and add to the end of the list
            active.Remove(obj);
            active.Add(obj);
            //Sleep more if a collision occurs
            Thread.Sleep(500);
        }
        public void Display() {
            Console.WriteLine("<<<<<< {0} >>>>>>", objectName);
            foreach (var s in active) {
                Console.WriteLine("{0}", s.Name);
            }
            Console.WriteLine("");
        }
    }
    class ObjectPool {
        private List<GameObject> objectPool = new List<GameObject>();
        public GameObject GetPooledObject() {
            GameObject reusedObject = null;
            for (int i = 0; i < objectPool.Count; ++i) {
                if (!objectPool[i].Enabled) {
                    reusedObject = objectPool[i];
                    break;
                }
            }
            if(canGrow && reusedObject == null) {
                Console.WriteLine("[Pool] Growing...");
                var newObject = creator();
                objectPool.Add(newObject);
                reusedObject = newObject;
            }
            reusedObject.Enabled = true;
            return reusedObject;
        }


        private bool canGrow = true;
        //private int capacity = 5;
        private Func<GameObject> creator;
        public ObjectPool(Func<GameObject> creator) {
            this.creator = creator;
        }
        public void AddObject(GameObject gm) {
            objectPool.Add(gm);
        }
    }
    */
}
