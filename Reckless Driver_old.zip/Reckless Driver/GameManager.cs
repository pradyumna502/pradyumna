﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Reckless_Driver {
    class GameManager {
        private float playerCash;
        public float PlayerCash {
            get {
                return playerCash;
            }
        }
        public void AddPlayerCash(float amount) {
            playerCash += amount;
        }
        private static GameManager instance = new GameManager();
        public static GameManager Instance {
            get { return instance; }
        }
        public void GameEnd() {
            //Show UI to restart or go to main menu
            Console.WriteLine("Cash earned : ${0}", playerCash);
            Console.WriteLine("Game has ended. What do you want to do?");
            Console.WriteLine("1. Restart");
            Console.WriteLine("2. Main Menu");
            Console.Write("? ");
            ConsoleKeyInfo info = Console.ReadKey();
            switch (info.Key) {
                case ConsoleKey.D1:
                    OnNewGame();
                    break;
                case ConsoleKey.D2:
                    break;
            }
            
        }
        public void OnNewGame() {
            //Choose player car
            Player player = new Player() {
                Name = "Player"
            };
            PlayerSedan ps = new PlayerSedan("Sedan", 5, 40, 5);
            player.Car = ps;
            Scene main = new Scene();
            main.Start(player);
           
            while (player.IsAlive) {
                Thread.Sleep(1000);
                Console.Clear();
                main.GenerateNPCs();
                //Player is driving the car
                Drive();
                main.Collide();
            }
            GameEnd();
        }
        private void Drive() {
            Console.WriteLine("\nPlayer is driving");
            for (int i = 0; i < 10; ++i) {
                Thread.Sleep(200);
                Console.Write(".");
            }
            Console.WriteLine("");
        }
    }
    

}
