﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver {
    class GameObject {
        private bool enabled;
        public virtual void OnCollision(GameObject other) {
            //Default implementation
        }
        public string Name { get; set; }
        public string Tag { get; set; }
        public bool Enabled {
            get {
                return enabled;
            }
            set {
                enabled = value;
                if (enabled)
                    OnEnabled();
                else
                    OnDisabled();
            }
        }
        public virtual void OnEnabled() {

        }
        public virtual void OnDisabled() {

        }
        
    }
   
   
}
