﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Reckless_Driver
{
    class ObjectPool
    {
        private List<GameObject> objectPool = new List<GameObject>();

        public GameObject GetPooledObject()
        {
            GameObject reusedObject = null;
            for (int i = 0; i < objectPool.Count; ++i)
            {
                if (!objectPool[i].Enabled)
                {
                    reusedObject = objectPool[i];
                    break;
                }
            }

            if (canGrow && reusedObject == null)
            {
                Console.WriteLine("[Pool] Growing...");
                var newObject = creator();
                objectPool.Add(newObject);
                reusedObject = newObject;
            }

            reusedObject.Enabled = true;
            return reusedObject;
        }


        private bool canGrow = true;

        //private int capacity = 5;
        private Func<GameObject> creator;

        public ObjectPool(Func<GameObject> creator)
        {
            this.creator = creator;
        }

        public void AddObject(GameObject gm)
        {
            objectPool.Add(gm);
        }
    }
}