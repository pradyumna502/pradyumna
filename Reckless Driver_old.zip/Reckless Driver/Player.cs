﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver {
    class Player : GameObject {
        public PlayerCar Car{get;set;}
        public int Health { get; set;  }
        public bool IsAlive {
            get;
            set;
        }
        public Player() {
            Health = 100;
            IsAlive = true;
        }
        public void OnUp() {
            Car.Accelerate();
        }
        public void OnDown() {
            Car.Brake();
        }
        public void OnLeft() {
            Car.MoveLeft();
        }
        public void OnRight() {
            Car.MoveRight();
        }
        
        public void ApplyDamage(int damage,int cash) {
            Health -= damage - Car.Strength;
            //UpdateUI
            Console.WriteLine("[Player] Health:{0}", Health);
            GameManager.Instance.AddPlayerCash(cash);
            if (Health <= 0) {
                IsAlive = false;
            }
        }
    }
    abstract class PlayerCar {
        public string Name { get; }
        public int Handling { get; }
        public int TopSpeed{get;}
        public int Strength{get;}
        public PlayerCar(string name, int handling, int topSpeed, int strength) {
            Name = name;
            Handling = handling;
            TopSpeed = topSpeed;
            Strength = strength;
        }
        public abstract void Accelerate();
        public abstract void Brake();
        public abstract void MoveLeft();
        public abstract void MoveRight();
    }
    class PlayerSedan : PlayerCar {
        public PlayerSedan(string name, int handling, int topSpeed, int strength) : base(name, handling, topSpeed, strength) {
        }

        public override void Accelerate() {
            Console.WriteLine("Accelerating");
        }

        public override void Brake() {
            throw new NotImplementedException();
        }

        public override void MoveLeft() {
            throw new NotImplementedException();
        }

        public override void MoveRight() {
            throw new NotImplementedException();
        }
    }
}
