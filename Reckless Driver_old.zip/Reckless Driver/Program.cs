﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            while (!exit) {
                Console.WriteLine("1. New game");
                Console.WriteLine("2. Options");
                Console.WriteLine("3. Exit");
                Console.Write("? ");
                ConsoleKeyInfo info = Console.ReadKey();
                switch (info.Key) {
                    case ConsoleKey.D1:
                        GameManager.Instance.OnNewGame();
                        break;
                    case ConsoleKey.D2:
                        //Not implemented
                        //OnOptions();
                        Console.WriteLine("Options");
                        break;
                    case ConsoleKey.D3:
                        Console.WriteLine("Exit");
                        exit = true;
                        //GameManager.Instance.OnExit();
                        break;
                    default:
                        break;
                }
                Console.Clear();
            }
            Console.WriteLine("Thanks for playing");
        }
    }
}
