﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Reckless_Driver {
    class Scene {
        ActiveObjects sideList = new ActiveObjects("Side Objects");
        ActiveObjects trafficCarList = new ActiveObjects("Traffic Cars");
        Player player;
        ObjectPool sideObjectsPool;
        ObjectPool trafficCarsPool;
        Random r = new Random();
        private void CreateGameObjects() {
            sideObjectsPool = new ObjectPool(() => {
                return SideObject.Create();
            });
            trafficCarsPool = new ObjectPool(() => {
                return TrafficCar.Create();
            });
        }
        public void Start(Player p) {
            player = p;
            //GenerateGameObjects();
            Thread th = new Thread(CreateGameObjects);
            th.Start();
        }
        public void GenerateNPCs() {
            //Remove oldest game object
            Remove(sideList);
            Remove(trafficCarList);


            //Generate traffic and side objects
            sideList.Add(sideObjectsPool.GetPooledObject());

            trafficCarList.Add(trafficCarsPool.GetPooledObject());

            sideList.Display();
            trafficCarList.Display();

        }
        public void Collide() {

            //Player smashes into random object (car or side object)
            switch (r.Next(0, 2)) {
                case 0://Collide with side object
                    sideList.Collide(player);

                    break;
                case 1://Collide with traffic car
                    trafficCarList.Collide(player);
                    break;
            }
        }
        private void Remove(ActiveObjects activeObj) {
            const int MAX_OBJECTS = 6;
            if (activeObj.GetCount() >= MAX_OBJECTS) {
                //Remove the oldest object
                activeObj.RemoveOldest();
            }
        }
    }
    class ActiveObjects {
        List<GameObject> active = new List<GameObject>();
        public void Add(GameObject go) {
            active.Add(go);
        }
        public string GetName() {
            return objectName;
        }
        private string objectName;
        public ActiveObjects(string name) {
            objectName = name;
        }
        public void RemoveOldest() {
            active[0].Enabled = false;
            active.RemoveAt(0);
        }
        public int GetCount() {
            return active.Count;
        }
        public void Collide(Player player) {
            Random r = new Random();
            GameObject obj = active[r.Next(active.Count)];
            obj.OnCollision(player);
            if (!player.IsAlive)
                return;
            //Remove this object and add to the end of the list
            active.Remove(obj);
            active.Add(obj);
            //Sleep more if a collision occurs
            Thread.Sleep(500);
        }
        public void Display() {
            Console.WriteLine("<<<<<< {0} >>>>>>", objectName);
            foreach (var s in active) {
                Console.WriteLine("{0}", s.Name);
            }
            Console.WriteLine("");
        }
    }
}
