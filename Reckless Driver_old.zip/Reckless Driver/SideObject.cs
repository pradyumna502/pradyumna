﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.IO;

namespace Reckless_Driver {
    class SideObject : GameObject {
        public int Damage { get; protected set; }
        public int Cash { get; protected set; }
        protected int count = 0;
        public static SideObject Create() {
            Random r = new Random();
            SideObject sideObj = null;
            switch (r.Next(0, 2)) {
                case 0://Firehydrant
                    sideObj = new FireHydrant(
                        Reckless_Driver.Damage.SideObject.FIREHYDRANT,
                        Reckless_Driver.Cash.SideObject.FIREHYDRANT);
                    break;
                case 1://
                    sideObj = new Postbox(
                        Reckless_Driver.Damage.SideObject.POSTBOX,
                        Reckless_Driver.Cash.SideObject.POSTBOX);
                    break;
                default:
                    return null;//Should not reach here
            }
            sideObj.Tag = "sideobject";
            return sideObj;
        }
    }
    class FireHydrant : SideObject {
        public FireHydrant(int damage,int cash) {
            Damage = damage;
            Cash   = cash;
            Name   = "FireHydrant";
        }
        public override void OnCollision(GameObject other) {
            //Play sound
            if (other.Name == "Player") {
                Player player = other as Player;
                if (count == 0) {
                    //Show water fountain
                    Console.WriteLine("##COLLISION -> [FireHydrant] Water fountain");
                    player.ApplyDamage(Damage, Cash);
                }
                else {
                    //TODO : Add bonus cash to player
                    Console.WriteLine("##COLLISION -> [FireHydrant] Collided again");
                    player.ApplyDamage(Damage, Cash * count);
                }
                ++count;
            }
        }
        public override void OnEnabled() {
            count = 0;
        }
    }
    class Postbox : SideObject {
        public Postbox(int damage, int cash) {
            Damage = damage;
            Cash = cash;
            Name = "PostBox";
        }
        public override void OnCollision(GameObject other) {
            //Play sound
            if (other.Name == "Player") {
                Player player = other as Player;
                if (count == 0) {
                    //Show letters flying out
                    Console.WriteLine("##COLLISION -> [Postbox] Letters flying out");
                    player.ApplyDamage(Damage, Cash);
                }
                else {
                    Console.WriteLine("##COLLISION -> [Postbox] Collided again");
                    player.ApplyDamage(Damage, Cash * count);
                }
                ++count;
            }
        }
        public override void OnEnabled() {
            count = 0;
        }
    }
}
namespace Test {
    public class GameObject {

    }
  

    abstract class SideObject {
        //Attributes
        //Methods
        public abstract void OnCollision(GameObject other);
    }

    interface Serializable {
        void Serialize(StreamWriter output);
        void Deserialize(StreamReader input);
    }
    class Fountain {
        //Implement sparks here
    }
    class FireHydrant : SideObject, Serializable {
        //Attributes
        //Methods
        private Fountain fountain;
        public override void OnCollision(GameObject other) {
            //Implementation
        }

        public void Serialize(StreamWriter output) {
            //Implementation
        }
        public void Deserialize(StreamReader input) {
            //Implementation
        }
    }
    //Represents active objects in the scene
    class ActiveObjects {
        List<SideObject> active = new List<SideObject>();
        public void Add(SideObject obj) {
            active.Add(obj);
        }
        //Other members
    }
    class ObjectPoolManager {
        List<SideObject> objects = new List<SideObject>();
        SideObject GetPooledObject() {
            return null;
        }
    }

}