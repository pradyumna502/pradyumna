﻿using System;
namespace Reckless_Driver {
    class TrafficCar : GameObject {
        public int Damage { get; set; }
        public int Speed { get; set; }
        public int Cash { get; set; }
        public static TrafficCar Create() {
            Random r = new Random();
            switch (r.Next(0, 2)) {
                case 0://Sedan
                    return new Sedan(
                        Reckless_Driver.Damage.TrafficCar.SEDAN,
                        Reckless_Driver.Cash.TrafficCar.SEDAN);
                case 1://Van
                    return new Van(
                        Reckless_Driver.Damage.TrafficCar.VAN,
                        Reckless_Driver.Cash.TrafficCar.VAN);
                default:
                    return null;
            }
        }
    }
    class Sedan : TrafficCar {
        public Sedan(int damage, int cash) {
            Damage = damage;
            Cash = cash;
            Name = "Sedan";
        }
        public override void OnCollision(GameObject other) {
            if (other.Name == "Player") {
                Player player = other as Player;
                //Show sparks
                Console.WriteLine("## COLLISION -> [Sedan] Sparks flying");
                player.ApplyDamage(Damage, Cash);
            }
        }
    }
    class Van : TrafficCar {
        public Van(int damage, int cash) {
            Damage = damage;
            Cash = cash;
            Name = "Van";
        }
        public override void OnCollision(GameObject other) {
            if (other.Name == "Player") {
                Player player = other as Player;
                //Show sparks/milk bottles falling
                Console.WriteLine("## COLLISION -> [Van] Sparks flying/milk bottles falling out");
                player.ApplyDamage(Damage, Cash);
            }
        }
    }
}