﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACar
{
    class Program
    {
        public static int userInputVehicleChoice;
        static void Main(string[] args)            
        {
           
            Truck.CreateTruckList();
            Sedan.CreateSedanList();
            Menu();
        }

        public static void Menu()
        {
            Console.WriteLine("|---------------------------------------------------------|");
            Console.WriteLine("| Welcome to RentACar Company based in This Virtual World |");
            Console.WriteLine("|---------------------------------------------------------|");
            Console.WriteLine();
            Console.WriteLine("1: Create Customer ");
            Console.WriteLine("2: Show rented vehicles ");
            Console.WriteLine("3: Exit ");

            int userInput = int.Parse(Console.ReadLine());

            switch (userInput)
            {
                case 1:
                    User.CreateUser();
                    Console.Clear();
                    MenuAfterCreatingUser();
                    break;
                case 2:
                    Console.Clear();
                    Rental.RentedVehicles();
                    Console.ReadKey();
                    break;
                case 3:
                    Console.WriteLine("Thanks for your time. Press enter to exit program.");
                    Console.ReadKey();
                    Environment.Exit(1);
                    break;
            }
        }
        public static void MenuAfterCreatingUser()
        {

            Console.WriteLine("|---------------------------------------------------------|");
            Console.WriteLine("| Welcome to RentACar Company based in This Virtual World |");
            Console.WriteLine("|---------------------------------------------------------|");
            Console.WriteLine();
            Console.WriteLine("1: Show Vehicles ");
            Console.WriteLine("2: Exit ");

            int userInput = int.Parse(Console.ReadLine());

            switch (userInput)
            {
                case 1:
                    Console.Clear();
                    Rental.ShowAllVehicles();
                    MenuAfterShowVehicles();
                    break;

                case 2:
                    Console.WriteLine("Thanks for your time. Press enter to exit program.");
                    Console.ReadKey();
                    Environment.Exit(1);
                    break;
                case 4:
                    Console.Clear();
                    Rental.RentedVehicles();
                    Console.ReadKey();
                    break;
            }
        }

        public static void MenuAfterShowVehicles()
        {
            Rental getDiscount = new Rental();
            Console.WriteLine();
            Console.Write("1: Choose car to rent: ");
            userInputVehicleChoice = int.Parse(Console.ReadLine());
            if (userInputVehicleChoice > 15)
            {
                
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("Enter valid option");
                MenuAfterShowVehicles();
                Console.WriteLine("-------------------------------------");
            }

            Console.Write("Is this the car you want to rent? Y / N: ");
            char yesNoInput = char.Parse(Console.ReadLine().ToUpper());
            

            switch (userInputVehicleChoice)
            {
                case 1:
                    Vehicles v = Vehicles.ListOfVehicles[0];
                    if (yesNoInput == 'Y' && v.IsRented == true)
                    {
                        Console.WriteLine("This car is rented!");
                        Console.WriteLine("Choose another vehicle");
                        Console.ReadKey();
                        Rental.ShowAllVehicles();
                        MenuAfterShowVehicles();
                        Console.ReadKey();
                    }
                    else if (yesNoInput == 'Y' && v.IsRented == false)
                    {
                        getDiscount.CalculateRentalTimeDays();
                        v.IsRented = true;
                        Console.WriteLine($"Total price: {Rental.TotalCost}");
                        Truck.printTruck((Truck)v, userInputVehicleChoice);
                        Menu();
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.Clear();
                        Rental.ShowAllVehicles();
                        MenuAfterShowVehicles();
                        Console.ReadKey();
                    }
                    break;

                case 2:
                    Vehicles v1 = Vehicles.ListOfVehicles[1];
                    if (yesNoInput == 'Y' && v1.IsRented == true)
                    {
                        Console.WriteLine("This car is rented!");
                        Console.ReadKey();
                        Rental.ShowAllVehicles();
                        MenuAfterShowVehicles();
                        Console.ReadKey();
                    }
                    else if (yesNoInput == 'Y' && v1.IsRented == false)
                    {
                        getDiscount.CalculateRentalTimeDays();
                        v1.IsRented = true;
                        Console.WriteLine($"Total price: {Rental.TotalCost}");
                        Truck.printTruck((Truck)v1, userInputVehicleChoice);
                        Menu();
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.Clear();
                        Rental.ShowAllVehicles();
                        MenuAfterShowVehicles();
                        Console.ReadKey();
                    }
                    break;
                case 3:
                    {
                        Vehicles v2 = Vehicles.ListOfVehicles[2];
                        if (yesNoInput == 'Y' && v2.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v2.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v2.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Truck.printTruck((Truck)v2, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 4:
                    {
                        Vehicles v3 = Vehicles.ListOfVehicles[3];
                        if (yesNoInput == 'Y' && v3.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v3.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v3.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Truck.printTruck((Truck)v3, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 5:
                    {
                        Vehicles v4 = Vehicles.ListOfVehicles[4];
                        if (yesNoInput == 'Y' && v4.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v4.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v4.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Truck.printTruck((Truck)v4, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 6:
                    {
                        Vehicles v5 = Vehicles.ListOfVehicles[5];
                        if (yesNoInput == 'Y' && v5.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v5.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v5.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v5, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 7:
                    {
                        Vehicles v6 = Vehicles.ListOfVehicles[6];
                        if (yesNoInput == 'Y' && v6.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v6.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v6.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v6, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 8:
                    {
                        Vehicles v7 = Vehicles.ListOfVehicles[7];
                        if (yesNoInput == 'Y' && v7.IsRented == true)
                        {

                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v7.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v7.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v7, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 9:
                    {
                        Vehicles v8 = Vehicles.ListOfVehicles[8];
                        if (yesNoInput == 'Y' && v8.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v8.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v8.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v8, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 10:
                    {
                        Vehicles v9 = Vehicles.ListOfVehicles[9];
                        if (yesNoInput == 'Y' && v9.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v9.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v9.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v9, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 11:
                    {
                        Vehicles v10 = Vehicles.ListOfVehicles[10];
                        if (yesNoInput == 'Y' && v10.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v10.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v10.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v10, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 12:
                    {
                        Vehicles v11 = Vehicles.ListOfVehicles[11];
                        if (yesNoInput == 'Y' && v11.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v11.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v11.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v11, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 13:
                    {
                        Vehicles v12 = Vehicles.ListOfVehicles[12];
                        if (yesNoInput == 'Y' && v12.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v12.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v12.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v12, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 14:
                    {
                        Vehicles v13 = Vehicles.ListOfVehicles[13];
                        if (yesNoInput == 'Y' && v13.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v13.IsRented == false)
                        {
                            getDiscount.CalculateRentalTimeDays();
                            v13.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v13, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 15:
                    {
                        Vehicles v14 = Vehicles.ListOfVehicles[14];
                       // Rental.DaysOrHoursInput();
                        if (yesNoInput == 'Y' && v14.IsRented == true)
                        {
                            Console.WriteLine("This car is rented!");
                            Console.ReadKey();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                        else if (yesNoInput == 'Y' && v14.IsRented == false)
                        {

                            getDiscount.CalculateRentalTimeDays();
                            v14.IsRented = true;
                            Console.WriteLine($"Total price: {Rental.TotalCost}");
                            Sedan.printSedan((Sedan)v14, userInputVehicleChoice);
                            Menu();
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.Clear();
                            Rental.ShowAllVehicles();
                            MenuAfterShowVehicles();
                            Console.ReadKey();
                        }
                    }
                    break;
                case 16:
                    Console.WriteLine("Thanks for your time. Press enter to exit program.");
                    Console.ReadKey();
                    Environment.Exit(1);
                    break;
                default:
                    Console.WriteLine("Wrong Input Please Try Again");
                    Console.ReadKey();
                    break;               
            }
        }

    }
}

