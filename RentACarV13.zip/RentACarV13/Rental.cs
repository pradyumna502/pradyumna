using System;
using System.Collections.Generic;

namespace RentACar
{
    public class Rental : ISevenDaysDiscount, IElectricDiscount
    {

        public static List<Rental> RentalHistoryList { get; set; }
        public static decimal totalCost;
        public static List<DateTime> ReturnDates = new List<DateTime>();
        public static DateTime returnDate;
        public static int TotalNumberOfVehicles = 15;
        //public static decimal UserHourInput;
        public static decimal UserDaysInput;
        public static int userInputSwitch;

        public const decimal BookingFee = 200;
        public const decimal HourFee = 100;

        public static decimal TotalCost
        {
            get
            {
                return totalCost;
            }
            set
            {
                totalCost = value;
            }
        }
        public static DateTime ReturnDate
        {
            get
            {
                return returnDate;
            }
            set
            {
                returnDate = value;
            }
        }

        public Rental()
        {
            RentalHistoryList = new List<Rental>();
        }
        

        public void CalculateRentalTimeDays()
        {
            DateTime startTime = DateTime.Now;
            DateTime endTime;
            int hours = 0;
            int days = 0;


       

            Vehicles v1 = new Vehicles();
            v1 = Vehicles.ListOfVehicles[Program.userInputVehicleChoice - 1];

            Truck t1 = new Truck();
            Sedan s1 = new Sedan();
           

            if (Program.userInputVehicleChoice > 0 && Program.userInputVehicleChoice <= 5)
            {
                t1 = (Truck)Vehicles.ListOfVehicles[Program.userInputVehicleChoice - 1];
            }
            if (Program.userInputVehicleChoice > 5 && Program.userInputVehicleChoice <= 15)
            {
                
                s1 = (Sedan)Vehicles.ListOfVehicles[Program.userInputVehicleChoice - 1];
            }
            if (v1.TypeOfCar == "TRUCK")
            {
                Truck.inputCargo(t1);
            }

            Console.WriteLine("For how long do you wish to rent the vehicle?");
            Console.WriteLine("1: A couple of hours");
            Console.WriteLine("2: A day or more");
            userInputSwitch = int.Parse(Console.ReadLine());
            while (userInputSwitch > 2)
            {
                Console.Write("You must choose a number between 1 and 2: ");
                userInputSwitch = int.Parse(Console.ReadLine());
            }

            switch (userInputSwitch)
            {

                case 1:
                    if (v1.TypeOfCar == "SEDAN")
                    {
                        Console.Write("Enter amount of hours:");
                        hours = Convert.ToInt32(Console.ReadLine());
                        if (hours >= 24)
                        {
                            while (hours >= 24)
                            {
                                Console.WriteLine("Please enter hour amount below 24h or choose option Days");
                                hours = Convert.ToInt32(Console.ReadLine());

                            }
                        }
                        if (hours < 24)
                        {
                            if (s1.IsElectric == true)
                            {
                                TotalCost = hours * HourFee * (1M - ElectricDiscountmethod()) + BookingFee;

                               
                            }
                            else if (s1.IsElectric == false)
                            {
                                TotalCost = hours * HourFee + BookingFee;
                              
                            }

                        }
                        SetTotalVehiclesInFleet();
                        endTime = startTime.AddHours(hours);
                        Console.WriteLine("\nWe expect the vechicle back at: " + endTime);
                        ReturnDate = endTime;
                        ReturnDates.Add(ReturnDate);

                    }
                    if (v1.TypeOfCar == "TRUCK")
                    {
                        Console.Write("Enter amount of hours: ");
                        hours = Convert.ToInt32(Console.ReadLine());
                        if (hours < 24)
                        {
                            TotalCost = hours * HourFee + BookingFee;
                            
                        }
                        else if (hours >= 24)
                        {
                            while (hours >= 24)
                            {
                                Console.WriteLine("Please enter hour amount below 24h or choose option Days");
                                hours = Convert.ToInt32(Console.ReadLine());
                            }
                            TotalCost = hours * HourFee + BookingFee;
                        }
                        SetTotalVehiclesInFleet();
                        endTime = startTime.AddHours(hours);
                        Console.WriteLine("\nWe expect the vechicle back at: " + endTime);
                        ReturnDate = endTime;
                        ReturnDates.Add(ReturnDate);

                    }
                    break;

                case 2:
                    
                    if (v1.TypeOfCar == "SEDAN")
                    {
                        Console.Write("Enter amount of days:");
                        days = Convert.ToInt32(Console.ReadLine());
                        if (days >= 7 && s1.IsElectric == true)
                        {
                            TotalCost = days * v1.DailyPrice * (1 - ElectricDiscountmethod() - SevenDiscountmethod()) + BookingFee;

                        }
                        else if (days >= 7 && s1.IsElectric == false)
                        {
                            TotalCost = days * v1.DailyPrice * (1 - SevenDiscountmethod()) + BookingFee;
                        }
                        else if (days < 7 && s1.IsElectric == true)
                        {
                            TotalCost = days * v1.DailyPrice * (1 - ElectricDiscountmethod()) + BookingFee;
                        }
                        else
                        {
                            TotalCost = days * v1.DailyPrice + BookingFee;
                        }
                    }
                    if (v1.TypeOfCar == "TRUCK")
                    {
                        Console.Write("Enter amount of days:");
                        days = Convert.ToInt32(Console.ReadLine());
                        if (days >= 7)
                        {
                            TotalCost = days * v1.DailyPrice * (1 - SevenDiscountmethod()) + BookingFee;

                        }
                        if (days < 7)
                        {
                            TotalCost = days * v1.DailyPrice + BookingFee;
                        }

                    }
                    SetTotalVehiclesInFleet();
                    endTime = startTime.AddDays(days);
                    Console.WriteLine("\nWe expect the vechicle back at: " + endTime);
                    ReturnDate = endTime;
                    ReturnDates.Add(ReturnDate);
                    break;
            }

        }


        public static void ShowAllVehicles()
        {
            Console.WriteLine("___________________________________________________________________________________");
            Console.WriteLine("");
            Console.WriteLine($"Vehicles available for rent: {TotalNumberOfVehicles} / 15");
            Console.WriteLine("");
            Console.WriteLine("___________________________________________________________________________________");
            Console.WriteLine("");
            Truck.ShowAllTrucks();
            Sedan.ShowAllSedans();

        }

        public static void RentedVehicles()
        {
            int i = 1;
            int u = 0;
            int j = 0;
            foreach (var vehicle in Vehicles.ListOfVehicles)
            {
                if (vehicle.IsRented == true)
                {

                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"{i} {vehicle.TypeOfCar}");
                    Console.WriteLine($"Manufacturer: {vehicle._manuf}");
                    Console.WriteLine($"RegistrationNr: {vehicle.RegistrationNumber}");

                    Console.WriteLine("This car is currently not availible");
                    //Console.WriteLine($"Rented: {vehicle.IsRented}");

                    Console.WriteLine($"Rented by: {User._customerList[u]}");
                    Console.WriteLine($"Available for rent again: {ReturnDates[j]}."); //Mattis testar
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine();
                    u++;
                   i++;
                    j++;
                }
                Console.ForegroundColor = ConsoleColor.White;
                
            }
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            Console.Clear();
            Program.Menu();

        }

        public static int SetTotalVehiclesInFleet()
        {
            TotalNumberOfVehicles -= 1;

            return TotalNumberOfVehicles;
        }

        public decimal ElectricDiscountmethod()
        {
            decimal discount = 0.1M;


            return discount;
        }
        public decimal SevenDiscountmethod()
        {
            decimal discount = 0.1m;


            return discount;
        }

    }
}
