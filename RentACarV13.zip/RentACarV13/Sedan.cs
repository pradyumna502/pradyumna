﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACar
{
    public class Sedan : Vehicles
    {
        //public static Sedan s = new Sedan();
        public int NumberOfSeats { get; set; } 
        public bool IsElectric { get; set; }



        public Sedan(string typeOfCar, Manufacturer manuf, string regNr, decimal dayPrice, int numbSeats, bool isElect, bool isRent, bool isRentWeek) 
                                : base(typeOfCar, manuf, regNr, dayPrice, isRent, isRentWeek)
        {
            TypeOfCar = typeOfCar;
            _manuf = manuf;
            RegistrationNumber = regNr;
            DailyPrice = dayPrice;
            NumberOfSeats = numbSeats;
            IsElectric = isElect;
            IsRented = isRent;

        }
 
        public static void CreateSedanList()
        {
            Sedan Saab1 = new Sedan("SEDAN", Manufacturer.Saab, "JON001", 6000, 4, false, false, true);
            Sedan Saab2 = new Sedan("SEDAN", Manufacturer.Saab, "EGH002", 6500, 4, true, false, true);

            Sedan BMV1 = new Sedan("SEDAN", Manufacturer.BMW, "LOR001", 7000, 4, false, false, true);
            Sedan BMV2 = new Sedan("SEDAN", Manufacturer.BMW, "MAH002", 7500, 4, true, false, true);

            Sedan Toyota1 = new Sedan("SEDAN", Manufacturer.Toyota, "DAN001", 700, 4, false, false, true);
            Sedan Toyota2 = new Sedan("SEDAN", Manufacturer.Toyota, "SOD007", 1200, 4, true, false, true);

            Sedan Volvo1 = new Sedan("SEDAN", Manufacturer.Volvo, "MAT001", 6001, 4, false, false, true);
            Sedan Volvo2 = new Sedan("SEDAN", Manufacturer.Volvo, "VAI002", 6501, 4, true, false, true);

            Sedan Mercedes1 = new Sedan("SEDAN", Manufacturer.Mercedes, "AND001", 5600, 4, false, false, true);
            Sedan Mercedes2 = new Sedan("SEDAN", Manufacturer.Mercedes, "PON002", 6100, 4, true, false, true);

            Vehicles.ListOfVehicles.Add(Saab1);
            Vehicles.ListOfVehicles.Add(Saab2);
            Vehicles.ListOfVehicles.Add(BMV1);
            Vehicles.ListOfVehicles.Add(BMV2);
            Vehicles.ListOfVehicles.Add(Toyota1);
            Vehicles.ListOfVehicles.Add(Toyota2);
            Vehicles.ListOfVehicles.Add(Volvo1);
            Vehicles.ListOfVehicles.Add(Volvo2);
            Vehicles.ListOfVehicles.Add(Mercedes1);
            Vehicles.ListOfVehicles.Add(Mercedes2);
        }
        // Method that shows every car we have in the ListOfSedans
        public static void ShowAllSedans()
        {
            int i = 6;
            foreach (var car in ListOfVehicles)
            {
                if (car.TypeOfCar == "SEDAN")
                {
                    if (car.IsRented == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                    }
                    printSedan((Sedan) car, i);
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine();
                    i++;
                }
            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static void printSedan(Sedan sedan, int i)
        {
            Console.WriteLine($"{i} {sedan.TypeOfCar}");
            Console.WriteLine($"Manufacturer: { sedan._manuf}");
            Console.WriteLine($"Registration number: {sedan.RegistrationNumber}");
            Console.WriteLine($"Day Price: {sedan.DailyPrice}");
            Console.WriteLine($"Number of seats: { sedan.NumberOfSeats}");

            if (sedan.IsElectric == true)
                Console.WriteLine("This is an electric car");
            if (sedan.IsRented == false)
                Console.WriteLine("This car is availible");
            if (sedan.IsRented == true)
                Console.WriteLine($"[RENTED] Avalible again: {Rental.ReturnDate}");   //lägg in datetime för när tillgänglig igen
            //Console.WriteLine($"Electric: { sedan.IsElectric}");
            //Console.WriteLine($"Rented: {sedan.IsRented}");
        }
    
        



        public Sedan()
        {

        }
        //public static bool GetElectricStatus(Sedan car)
        //{
        //    Sedan s1 = new Sedan();
            
            
        //    if (s1.IsElectric == true)
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }

        //}


    }
}
