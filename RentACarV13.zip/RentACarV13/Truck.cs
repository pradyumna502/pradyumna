﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACar
{

    public class Truck : Vehicles
    {
        public int CargoCapacity { get; set; }

        //public bool CheckCapacity()
        //{
        //    return true;
        //}


        public Truck(string typeOfCar, Manufacturer manuf, string regNr, decimal dayPrice, int cargoCap, bool isRent, bool isRentWeek) 
            : base( typeOfCar, manuf, regNr, dayPrice, isRent, isRentWeek)
        {
            TypeOfCar = typeOfCar;
            _manuf = manuf;
            RegistrationNumber = regNr;
            DailyPrice = dayPrice;
            CargoCapacity = cargoCap;
            IsRented = isRent;
            IsRentedForMoreThenAWeek = isRentWeek;
        }

        public static void CreateTruckList()
        {


            Truck tSaab = new Truck("TRUCK", Manufacturer.Saab, "JON003", 7000, 4000, false, true);

            Truck tBMV = new Truck("TRUCK", Manufacturer.BMW, "LOR003", 8000, 1500, false, true);

            Truck tToyota = new Truck("TRUCK", Manufacturer.Toyota, "DAN003", 1700, 2500, false, true);

            Truck tVolvo = new Truck("TRUCK", Manufacturer.Volvo, "MAT003", 7001, 10000, false, true);

            Truck tMercedes = new Truck("TRUCK", Manufacturer.Mercedes, "AND003", 6600, 3000, false, true);
            
            ListOfVehicles.Add(tSaab);
            ListOfVehicles.Add(tBMV);
            ListOfVehicles.Add(tToyota);
            ListOfVehicles.Add(tVolvo);
            ListOfVehicles.Add(tMercedes);
        }

        public static void ShowAllTrucks()
        {
            int i = 1;
            foreach (var car in ListOfVehicles)
            {
                if (car.TypeOfCar == "TRUCK")
                {
                    
                    if (car.IsRented == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    else if(car.IsRented == false)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                    }
                    printTruck((Truck)car, i);
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine();
                    i++;
                }
            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static void printTruck(Truck truck, int i)
        {
            Console.WriteLine($"{i} {truck.TypeOfCar}");
            Console.WriteLine($"Manufacturer: {truck._manuf}");
            Console.WriteLine($"RegistrationNr: {truck.RegistrationNumber}");
            Console.WriteLine($"Day Price: {truck.DailyPrice}");
            Console.WriteLine($"CargoCap: {truck.CargoCapacity}");
            if (truck.IsRented == true)
                Console.WriteLine("[RENTED]");
            if (truck.IsRented == false)
                Console.WriteLine("This car is availible");

            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine();
        }

       

        public static void inputCargo(Truck truck)
        {

            Console.WriteLine("How much do you plan to load on the truck? (kg) ");
            int kg = Convert.ToInt32(Console.ReadLine());
            int cargoCap = truck.CargoCapacity;
            if (kg > cargoCap)
            {
                Console.WriteLine("To heavy load for this truck, check CargoCapacity");
                Program.MenuAfterShowVehicles();
            }

        }
        public Truck()
        {

        }
       

    }
}
