﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACar
{
 
    public class Vehicles
    {
        public enum Manufacturer { Volvo, Saab, Toyota, BMW, Mercedes }
        public Manufacturer _manuf { get; set; }

        public string TypeOfCar { get; set; }
        public string RegistrationNumber { get; set; }
        public decimal DailyPrice { get; set; }
        public bool IsRented { get; set; }
        public bool IsRentedForMoreThenAWeek { get; set; }
        public decimal HourFee { get; set; }
        
       // public int CargoCapacity { get; set; }

        public static List<Vehicles> ListOfVehicles { get; set; } = new List<Vehicles>();

        public Vehicles(string typeOfCar, Manufacturer manuf, string regNr, decimal dayPrice, bool isRent, bool isRentWeek)
        {
            TypeOfCar = typeOfCar; //done
            _manuf = manuf; //done
            RegistrationNumber = regNr; //done
            DailyPrice = dayPrice; //done
            IsRented = isRent;
            IsRentedForMoreThenAWeek = isRentWeek;
            HourFee = 100M;

        }
        public Vehicles()
        {

        }

    }
}
