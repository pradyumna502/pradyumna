﻿using System;
namespace Car
{
    public class Engine
{
    public string Size;
    public int HorsePower;
    public double FuelConsumtionRate;

    public Engine()
    {
    }

    public Engine(string cylinder, int hp, double fuelRate)
    {
        Size = cylinder;
        Console.WriteLine($"Engine type: {cylinder}");
        HorsePower = hp;
        Console.WriteLine($"Horse power: {hp} hp");
        FuelConsumtionRate = fuelRate;
        Console.WriteLine($"Fuel consumption: {fuelRate} l/h");
    }

    //     /*   

    //        public static void ChooseEngine()
    //        {
    //            //Engine v4 = new Engine("v4", 200, 0.7);

    //            //Engine v6 = new Engine("v6", 300, 4.1);

    //            //Engine v8 = new Engine("v8", 400, 3.1);

    //        }
    //        */
}
}
