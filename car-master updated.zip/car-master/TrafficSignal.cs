﻿using System;
namespace Car
{
    public enum TraficSignal { GREEN, YELLOW, RED };

    public class TrafficSignal
    {
        public TraficSignal signal = TraficSignal.GREEN;
        public bool SignalStatus = false;

        public void ValidSignal()
        {
            if (signal == TraficSignal.GREEN)
            {
                SignalStatus = true;
            }

        }
        public TrafficSignal()
        {

        }

        public static void CheckValidSignal()
        {
            TrafficSignal tf = new TrafficSignal();
            tf.ValidSignal();

        }

    }
}
