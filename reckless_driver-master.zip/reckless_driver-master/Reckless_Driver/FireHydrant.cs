﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    public class FireHydrant:SideObject
    {
        public FireHydrant(int damage, int cash) : base(damage, cash)
        {
            Name = "FireHydrant";
            Cash = cash;
        }

        public override void OnCollision(GameObject other)
        {
            if (other.Name == "Player")
            {
                Player player = other as Player;

                if(Count == 0)
                {
                    Console.WriteLine("#### COLLISION -> [Firehydrant] Fountain");
                    player.ApplyDamage(Damage, Cash);
                }
                else
                {
                    Console.WriteLine("#### COLLISION -> [Firehydrant] Collided again");
                    player.ApplyDamage(Damage, Cash * Count);
                }
            }
        }
    }
}
