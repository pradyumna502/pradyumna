﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Reckless_Driver
{
    public class GameManager
    {
        //Total accumulated cash by a player
        private int cash;

        //method
        public int Cash
        {
            get
            {
                return cash;
            }
        }

        public void AddCash(int amount)
        {
            cash += amount;
        }

        //new game
        public void NewGame()
        {
            //Choose vehicle
            //Parameter for type of vehicle, handling(between 0 to 10), top speed and strength(between 0 to 10)
            PlayerVehicle vehicle = new PlayerVehicle("Sedan", 5, 70, 4);

            //Create a player object and assign a vehicle to it, specify the health and vehicle
            Player player = new Player("Sohail", 100, vehicle);
            player.Name = "Player";

            //Prepare the scenery, will contain the game objects, add class Scene
            //Create a instance of Scene
            Scene scene = new Scene();

            //Initialize it with a player
            scene.Start(player);

            //Player starts the car, and the player will continue to do so as
            //long as health is larger then 0
            //Run a Loop

            while (player.IsAlive)
            {
                //Generate gameobjects (sideobjects,traffic, etc..)
                scene.GenerateNPCs();

                //Display message player is driving the car
                Drive();

                //Player might collide with other objects
                scene.Collide();

                //Repeat until health > 0
                EndGame();
            }



        }

        private void Drive()
        {
            Console.WriteLine("\nPlayer is driving");
            //Add a small delay
            for (int i = 0; i > 10; ++i)
            {
                Thread.Sleep(300);
                Console.Write(".");
            }
            Console.WriteLine("");
        }

        public void EndGame()
        {
            Console.WriteLine("Total accumulated cash: {0}", cash);

        }

    }
}
