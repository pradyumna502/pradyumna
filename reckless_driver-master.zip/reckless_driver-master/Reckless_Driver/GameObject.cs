﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    public class GameObject
    {

        public string Name
        {
            get; set;
        }
        private String Tag
        {
            get; set;
        }

        public bool Enabled
        {
            get; set;
        }
        //Meant to be overidden in child classes with their own implementation
        //We choose not to make this method abstract, because all gameobject
        //have to then implement this method, even game object as houses.
        public virtual void OnCollision(GameObject other)
        {


        }

        //Empty constructor
        public GameObject()
        {
        }
    }
}
