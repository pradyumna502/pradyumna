﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    public class LetterBox:SideObject
    {
        public LetterBox(int damage, int cash) : base(damage, cash)
        {
            Name = "Letterbox";
        }

        //methods
        public override void OnCollision(GameObject other)
        {
            if (other.Name == "Player")
            {
                Player player = other as Player;

                if (Count == 0)
                {
                    Console.WriteLine("#### COLLISION -> [LetterBox] Letters");
                    player.ApplyDamage(Damage, Cash);
                }
                else
                {
                    Console.WriteLine("#### COLLISION -> [LetterBox] Collided again");
                    player.ApplyDamage(Damage, Cash * Count);
                }
            }
        }
    }
}
