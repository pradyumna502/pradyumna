﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    //PickupTruck Inherits TrafficCar
    public class PickupTruck:TrafficCar
    {
        //Inherit Constructor attributes from parent class TrafficCar
        public PickupTruck(int damage, int cash):base(damage, cash)
        {
        }


        //Virtual method from parent class GameObject overidden here
        public override void OnCollision(GameObject other)
        {
            base.OnCollision(other);
        }

    }
}
