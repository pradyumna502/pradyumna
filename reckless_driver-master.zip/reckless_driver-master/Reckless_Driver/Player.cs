﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    public class Player:GameObject
    {
        public int Health;
        public PlayerVehicle Vehicle { get; set; }


        public Player(string v, int health, PlayerVehicle vehicle)
        {
            Name = "Player";
            Health = health;
            Vehicle = vehicle;
        }


        //read only property
        public bool IsAlive
        {
            get
            {
                return Health > 0;
            }
        }

        //public string Name { get; internal set; }


        //Methods
        public void ApplyDamage(int damage, int cash)
        {
            Health -= Vehicle.Strength;
            Console.WriteLine("Health is: {0}" ,Health);
           
        }

        public void Accelerate()
        {
            Vehicle.Up();
        }

        public void Brake()
        {
            Vehicle.Back();
        }

        public void SteerLeft()
        {
            Vehicle.Left();
        }

        public void SteerRight()
        {
            Vehicle.Right();
        }
    }
}
   