﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 Note that in this game we dont have graphics, so the playcer cannot actually
 driver the car.
 But we will simulate that effect by printing a message that the player is
 driving the car.
 And also simulate the collison between the player car and different kinds of
 objects such as sideobjects and traffic vehicle.
 */

namespace Reckless_Driver
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*
            GameObject go = new GameObject();
            go.Enabled = true;
            bool e = go.Enabled;
            */
            GameManager mgr = new GameManager();
            mgr.NewGame();
        }
    }
}
