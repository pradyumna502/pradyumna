﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Reckless_Driver
{
    public class Scene
    {
        //Total nr of sideobjects and traffic in game
        private const int SIDEOBJECT_COUNT = 2;
        private const int TRAFFIC_COUNT = 2;

        //Total nr of objects the player can collide with
        private const int NPC_TYPES = 2;

        private List<SideObject> sideList = new List<SideObject>();
        private List<TrafficCar> trafficList = new List<TrafficCar>();

        //refernce of player
        private Player player;

        //Randomly choose between different sideobjects and traffic vehicles
        private Random random = new Random();

        //Methods
        //Initialze player reference
        public void Start(Player player)    
        {
            this.player = player;
        }

        //Generate game objects

        /*
        Randomly generate side objects and traffic, and then add the
        generated objects to their corrosponding lists
        */
        public void GenerateNPCs()
        {
            //Invoke methods to generate NPCs
            //Add the generated side objects to the sideList
            sideList.Add(GenerateSideObjects());

            //Add the generated traffic objects to the trafficList
            trafficList.Add(GenerateTraffic());

            //display sideobjects and traffic
            DisplaySideObjects();
            DisplayTraffic();

        }

        /*
         method for collistion, randomly collide with sideobjects or traffic.
         This method will have the player car randomly collide with the
         different objects
         */
        public void Collide()
        {
            /*Create a reference of gameobject, and then randomly generate
             objects the player can collide with*/
            GameObject go = null;
            switch (random.Next(NPC_TYPES))
            {
                //Generate sideobjects
                case 0:
                    /*randomly choose a sideobject from the sidelist, use a
                     indexer or subscript operator, get a random number from 0
                     to the total number of sideobjects in the sidelist. Based
                     on that, choose a object from the sidelist*/
                    go = sideList[random.Next(sideList.Count)];
                    break;
                //Generate trafficobjects
                case 1:
                    //repeat as above but this time for trafficobjects
                    go = trafficList[random.Next(trafficList.Count)];
                    break;
            }

            /*If the gameobject is not null, then a object has been generated
             with which the player will collide, then create a slight delay
             of 1 second to show the message of collison*/

            
            if (go != null)
            {
                //Make gameobject "go" collide with the player
                go.OnCollision(player);
                Thread.Sleep(1000);
            }

        }

        //methods for generateing side and traffic objects
        private SideObject GenerateSideObjects()
        {
            switch (random.Next(SIDEOBJECT_COUNT))
            {
                /*Firehydrant, hitting the firehydrant will cause 5 units of
                 damage and 10 units of cash will be accumulated*/
                case 0:
                    return new FireHydrant(5, 10);
                /*Letterbox hitting the letterbox will cause 8 units of
                 damage and 13 units of cash will be accumulated*/
                case 1:
                    return new LetterBox(8, 13);
                default:
                    break;

            }
            return null;
        }

        private TrafficCar GenerateTraffic()
        {
            switch (random.Next(TRAFFIC_COUNT))
            {
                /*Sedan, hitting the sedan will cause 15 units of
                 damage and 80 units of cash will be accumulated*/
                case 0:
                    return new Sedan(15, 80);
                /*Van hitting the letterbox will cause 18 units of
                 damage and 90 units of cash will be accumulated*/
                case 1:
                    return new Van(18, 90);
                default:
                    break;

            }
            return null;
        }

        //methods to display the generated objects
        //Either use class name or use var, var in c# can deduct objectype
        private void DisplaySideObjects()
        {
            Console.WriteLine("<<<<< SIDEOBJECTS >>>>>");
            foreach (var obj in sideList)
            {
                Console.WriteLine(obj.Name);
            }

        }

        private void DisplayTraffic()
        {
            Console.WriteLine("<<<<< TRAFFIC >>>>>");
            foreach (var obj in trafficList)
            {
                Console.WriteLine(obj.Name);
            }

        }


    }
}
