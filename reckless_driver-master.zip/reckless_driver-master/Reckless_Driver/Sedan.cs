﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    //Sedan Inherits TrafficCar
    public class Sedan:TrafficCar
    {
        //Inherit Constructor attributes from parent class TrafficCar
        public Sedan(int damage, int cash):base(damage, cash)
        {
            Name = "Sedan";
        }


        //Virtual method from parent class GameObject overidden here
        public override void OnCollision(GameObject other)
        {
            if (other.Name == "Player")
            {
                Player player = other as Player;
                
                    Console.WriteLine("#### COLLISION -> [Sedan] Sparks Flying");
                    player.ApplyDamage(Damage, Cash);
      
            }
        }

    }
}
