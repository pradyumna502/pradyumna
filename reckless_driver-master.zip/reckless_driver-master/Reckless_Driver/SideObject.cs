﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    public class SideObject:GameObject
    {

        public int Damage { get; set; }
        public int Cash { get; set; }

        protected int Count = 0;

        //constructor
        /*
        public SideObject(int damage, int cash, string name)
        {
            Damage = damage;
            Cash = cash;
            Name = name;
        }

    */


        public SideObject(int damage, int cash)
        {
            Damage = damage;
            Cash = cash;
        }
    }
}
