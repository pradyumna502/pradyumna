﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    public class Tree:SideObject
    {
        public Tree(int damage, int cash) : base(damage, cash)
        {

        }

        public override void OnCollision(GameObject other)
        {
            base.OnCollision(other);
        }
    }
}
