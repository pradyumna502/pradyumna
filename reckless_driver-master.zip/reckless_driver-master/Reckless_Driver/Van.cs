﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reckless_Driver
{
    //Van Inherits TrafficCar
    public class Van : TrafficCar
    {

        //Inherit Constructor attributes from parent class TrafficCar
        public Van(int damage, int cash) : base(damage, cash)
        {
            Name = "Van";
        }

        //Virtual method from parent class GameObject overidden here
        public override void OnCollision(GameObject other)
        {
            if (other.Name == "Player")
            {
                Player player = other as Player;

                Console.WriteLine("#### COLLISION -> [Van] Milk bottles falling");
                player.ApplyDamage(Damage, Cash);

            }
        }
    }
}