﻿using System;
namespace Application
{
    public class Scene
    {
        public Scene()
        {
        }
    }
}
