﻿using System;
namespace School
{
    public class EntryCard
    {
        string CardNr;
        bool Valid;

        public EntryCard(string cnr, bool isValid)
        {
            CardNr = cnr;
            Valid = isValid;
        }

        public EntryCard()
        {
        }

        //A association to the teacher class, takes the teacher as a argument.
        //Then show the date time when used.
        public void Swipe(Teacher obj)
        {
            if (Valid == true)
            {
                Console.WriteLine($"Card swipted at: {DateTime.Now}");
            }
        }
    }
}
