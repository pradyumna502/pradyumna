﻿using System;
namespace School
{
    /*
     IG is failing
     G is passing
     VG is above average
     MVG is the top grade
     */
    public enum Grades { IG, G, VG, MVG}
    public class Grade
    {
        private Student student;
        public bool IsSucess { get; set; }

        public Grades grade { get; set; }

        /*
         If the grade is IG, then the status of grade is false
         */
        public void GradeStatus()
        {
            if (grade == Grades.IG)
            {
                IsSucess = false;
            }
            else IsSucess = true;
        }

        /*
         if the previous grade status is true, then success
         */
        public bool isSuccess
        {
            get{ return isSuccess; }
            set {
                isSuccess = value;
                if (value)
                {
                    student.Status = true;
                }
                else
                {
                    student.Status = false;
                }
            }
        }


        /*
         Sets the grade and uses the Student as a argument
         */
        public Grade(Student obj)
        {
            student = obj;
        }

        public Grade()
        {
        }
    }
}
