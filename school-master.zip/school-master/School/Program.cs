﻿using System;

namespace School
{
    class MainClass : Student
    {
        public static int accountNumberMarker = 1000;
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter StudentName");
            string StudentName = Console.ReadLine();
            int StudentId = ++accountNumberMarker;
            Student student = new Student(StudentName, StudentId, true);
            Teacher.Students.Add(student);
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("-------------------");
            Console.WriteLine("1: Show Students");
            string command = Console.ReadLine();
            switch (command)
            {
                case "1":
                    Student.showallstudents();
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }
        }

    }
}
