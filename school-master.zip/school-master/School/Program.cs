﻿using System;

namespace School
{
    class MainClass : Student
    {

        public static void Main(string[] args)
        {
            Teacher.mainmenu();
        }

    }
}
