﻿using System;
namespace School
{
    public class Student
    {
        //Composiion relation to the Grade class
        public Grade grade;
        string StudentName { get; set; }
        int StudentId { get; set; }
        //Status of passing or failing
        public bool Status { get; set; }

        public Student(string sn, int sid, bool status)
        {
            StudentName = sn;
            StudentId = sid;
            Status = status;
        }


        /*
         If grade is value is true from the Grade class, the the the student
         passes
         */
        public void GraduateStatus(bool pass)
        {
            if (grade.IsSucess == true)
            {
                Status = true;
            }
            else Status = false;
        }

        public Student()
        {
            grade = new Grade(this);
        }
        public static void showallstudents()
        {
            foreach (Student myCustomer in Teacher.Students)
            {
                Console.WriteLine("Student Id: {0}, \n StudentName: {1}",myCustomer.StudentId, myCustomer.StudentName);
            }
        }
    }
}
