﻿using System;
using System.Collections.Generic;

namespace School
{
    public class Teacher : Employee

    {
        //Aggregation, A teacher has many students, also create a list of students
        public static List<Student> Students = new List<Student>();

        string GraduateLevel;

        //Inheritance The teacher inherits from its parent, the Employee class
        public Teacher(string gl, string name, int enr) : base(name, enr)
        {
            GraduateLevel = gl;
            Name = name;
            EmployeeNr = enr;
        }

        public Teacher()
        {
        }

        //A association to card class, takes the EntryCard as argument
        public void checkEntry(EntryCard obj)
        {
            obj.Swipe(this);
        }

        /*
         This is the abstract method implemented from the parent employee class.
         Generate a employee nr, either by some randomizer och start with
         1000 and add 1 for each emaployee
         Then check if there is a employee nr bigger then 0 and print the
         employee nr*/
        public override void checkCredentials()
        {
            if (EmployeeNr > 0)
            {
                Console.WriteLine("Enter Username");
                string name = Console.ReadLine();
                Console.WriteLine("Enter Password");
                string password = Console.ReadLine();
                if (name == "admin" && password == "admin")
                {
                    Teacher teacher = new Teacher();
                    teacher.checkCredentials();
                }
                else
                {
                    Console.WriteLine("Invalid details");
                }

                Console.WriteLine("Valid Employee: {0}", EmployeeNr);
            }
        }
    }
}
