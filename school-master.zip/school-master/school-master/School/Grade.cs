﻿using System;
using System.ComponentModel.DataAnnotations;

namespace School
{
    /*
     IG is failing
     G is passing
     VG is above average
     MVG is the top grade
     */
    //public enum Grades { IG, G, VG, MVG }
    public enum Grades
    {
        [Display(Name = "IG")] IG = 1,

        [Display(Name = "G")] G = 2,

        [Display(Name = "VG")] VG = 3,

        [Display(Name = "MVG")] MVG = 4
    }
    public class Grade
    {
        private Student student;
        private static bool stat;

        public bool IsSucess { get; set; }

        public Grades grade { get; set; }

        /*
         If the grade is IG, then the status of grade is false
         */
        public void GradeStatus( string Grd)
        {
            if (Grd == "IG")
            {
                IsSucess = false;
            }
            else if (Grd == "G")
            {
                IsSucess = true;
            }
            else if (Grd == "VG")
            {
                IsSucess = true;
            }
            else IsSucess = true;

            //return IsSucess;
        }

        /*
         if the previous grade status is true, then success
         */
        public bool isSuccess
        {
            get { return isSuccess; }
            set
            {
                isSuccess = value;
                if (value)
                {
                    student.Status = true;
                }
                else
                {
                    student.Status = false;
                }
            }
        }


        /*
         Sets the grade and uses the Student as a argument
         */
        public Grade(Student obj)
        {
            student = obj;
        }

        public static void AddGrade()
        {
            string grades;
            Console.WriteLine("Enter Studnet Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Studnet Id");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Student grade");
            Console.WriteLine("Provide garde");
            Console.WriteLine("1. IG -- Failing ");
            Console.WriteLine("2. G -- Passing");
            Console.WriteLine("3. VG -- Above Average");
            Console.WriteLine("4. MVG -- Top Grade");
            int command = Convert.ToInt32(Console.ReadLine());

            if (command == Convert.ToInt32(Grades.IG))
            {
                grades = "IG";
                stat = false;

            }
            else if (command == Convert.ToInt32(Grades.G))
            {
                grades = "G";
                stat = true;
            }
            else if (command == Convert.ToInt32(Grades.VG))
            {
                grades = "VG";
                stat = true;
            }

            else
            {
                grades ="MVG";
                stat = true;

            }
            //stat = GradeStatus(grades);
            if (Teacher.Students.Count > 0)
            {
                foreach (Student student in Teacher.Students)
                {
                    if (name == student.StudentName && id == student.StudentId && stat == true)
                    {
                        Student student1 = new Student(name, id, stat);
                        Teacher.teachermenu();
                    }
                    else if (name == student.StudentName && id == student.StudentId)
                    {
                        Student student1 = new Student(name, id);
                        Teacher.teachermenu();
                    }
                    else
                    {
                        Console.WriteLine("Student ID: {0} is already exists.",id);
                        Console.ReadLine();
                        Console.Clear();
                        Teacher.teachermenu();
                    }
                }
            }
            else
            {
                Student student1 = new Student(name, id, stat);
                Teacher.teachermenu();
            }
        }
    }
}
