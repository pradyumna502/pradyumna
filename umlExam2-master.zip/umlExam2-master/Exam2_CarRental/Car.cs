﻿using System.Collections.Generic;

namespace Exam2_CarRental
{
    public class Car
    {
        public enum Maker { SAAB, Volvo, Tesla, Tata };
        public Maker _manuf { get; set; }

        public string TypeOfCar { get; set; }
        public string RegistrationNumber { get; set; }
        public decimal DailyPrice { get; set; }
        public bool IsRented { get; set; }
        public bool IsRentedForMoreThenAWeek { get; set; }
        public decimal HourFee { get; set; }


        //static modifier is shared between all the objects
        //list is a dynamic array(Collection class)
        private static List<Rental> rentals = new List<Rental>();
        private static List<Sedan> sedans = new List<Sedan>();
        private static List<Truck> trucks = new List<Truck>();


        //Constructor

        protected Car()
        {
            sedans = new List<Sedan>();
            trucks = new List<Truck>();
        }

        public static List<Sedan> AllSedans
        {
            get { return sedans; }
        }

        public static List<Truck> AllTrucks
        {
            get { return trucks; }
        }

        public static List<Car> ListOfVehicles { get; set; } = new List<Car>();
        public Car(string typeOfCar, Maker manuf, string regNr, decimal dayPrice, bool isRent, bool isRentWeek)
        {
            TypeOfCar = typeOfCar; 
            _manuf = manuf; 
            RegistrationNumber = regNr; 
            DailyPrice = dayPrice; 
            IsRented = isRent;
            IsRentedForMoreThenAWeek = isRentWeek;
            HourFee = 100M;

        }
        public Car()
        {

        }

        //property method to get a list of rentals,
        public static List<Rental> AllRentals
        {
            get
            {
                return rentals;
            }
        }
    }
}
