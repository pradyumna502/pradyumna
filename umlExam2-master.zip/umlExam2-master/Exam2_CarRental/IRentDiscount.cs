﻿namespace Exam2_CarRental
{
    public interface IRentDiscount
    {
        decimal OverOneWeekDiscount();
    }
}
