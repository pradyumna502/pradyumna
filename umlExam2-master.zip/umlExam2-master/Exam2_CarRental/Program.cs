﻿using System;
using System.Threading;

namespace Exam2_CarRental
{
    class MainClass
    {
        public static int userInputVehicleChoice;
        public static void Main(string[] args)
        {
            ShowMainMenu();
        }

        public static void ShowAllCustomers()
        {
            foreach (Customer myCustomer in CarRental.AllCustomers)
            {
                Console.WriteLine("Name: {0}, Id:{1}", myCustomer.Name, myCustomer.CusId);
            }
            Console.ReadLine();
            MainClass.ShowMainMenu();
        }
        public static void ShowMainMenu()
        {
            Console.Clear();
            Console.WriteLine("-------------------");
            Console.WriteLine("1: Create customer");
            Console.WriteLine("2: Show customer ");
            Console.WriteLine("3: Exit");
            Console.WriteLine("-------------------");
            string command = Console.ReadLine();

            switch (command)
            {
                case "1":
                    CreateCustomer();
                    break;
                case "2":
                    ShowAllCustomers();
                    break;
                case "3":
                    Environment.Exit(1);
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    Console.ReadLine();
                    ShowMainMenu();
                    break;
            }
        }
        public static int accountNumberMarker = 1000;

        public static void CreateCustomer()
        {
            Console.Clear();
            Console.WriteLine("----------------------------------");
            Console.WriteLine("New Customer");
            Console.WriteLine("----------------------------------");
            Console.WriteLine();
            Console.Write("Please enter the Name: ");
            string name = Console.ReadLine();
            int id = ++accountNumberMarker;
            Customer customer = new Customer();
            customer.Name = name;
            customer.CusId = id;
            CarRental.AllCustomers.Add(customer);
            Console.WriteLine("Hurray....Customer Created Sucessfully.");
            Thread.Sleep(1000);
            MainClass.ShowMainMenu();
        }

        public static void ShowMainMenuafterusers()
        {
            Console.Clear();
            Console.WriteLine("-------------------");
            Console.WriteLine("1: Take Rent");
            Console.WriteLine("2: Show Sedans");
            Console.WriteLine("3: Show Trucks ");
            Console.WriteLine("4: Show Electric Vehicles");
            Console.WriteLine("5: Main Menu");
            Console.WriteLine("-------------------");
            string command = Console.ReadLine();

            switch (command)
            {
                case "1":
                    Sedan.CreateSedanList();
                    break;
                case "2":
                    Sedan.CreateSedanList();
                    break;
                case "3":
                    Truck.CreateTruckList();
                    break;
                case "4":
                    Environment.Exit(1);
                    break;
                case "5":
                    Console.WriteLine("Do you really want to Exit to Main Menu");
                    Console.WriteLine("Yes");
                    Console.WriteLine("No");
                    string check = Console.ReadLine();
                    switch (check)
                    {
                        case "Yes":
                            Console.WriteLine("Redirecting..........");
                            Thread.Sleep(1000);
                            Console.Clear();
                            ShowMainMenu();
                            break;
                        case "No":
                            Console.Clear();
                            ShowMainMenuafterusers();
                            break;
                        default:
                            Console.WriteLine(" Invalid Choice");
                            Console.Clear();
                            ShowMainMenuafterusers();
                            break;
                    }
                    break;
                default:
                    Console.WriteLine("Invalid Choice. Please provide input Again,,,,");
                    Thread.Sleep(1000);
                    Console.Clear();
                    ShowMainMenuafterusers();
                    break;
            }
        }
    }
}