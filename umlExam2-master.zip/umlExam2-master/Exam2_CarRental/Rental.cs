﻿using System;
using System.Collections.Generic;

namespace Exam2_CarRental
{
    public class Rental : IRentDiscount, IElectric
    {
        public static List<Rental> RentalHistoryList { get; set; }
        public static List<DateTime> ReturnDates = new List<DateTime>();
        public static decimal totalCost { get; set; }
        private DateTime ReturnDate { get; set; }
        private Car GetCar;
        private Customer GetCustomer;
        private bool Status;
        public static int TotalNumberOfVehicles = 15;
        public static int Numberofdays;
        public static int userInputSwitch;
        public const decimal HourFee = 100;

        //Constructors
        public Rental()
        {
            RentalHistoryList = new List<Rental>();
        }
        public static int SetTotalVehiclesInFleet()
        {
            TotalNumberOfVehicles -= 1;

            return TotalNumberOfVehicles;
        }
        /*
         Display a list of all rented Cars
         */
        public void listRentedCars()
        {
            int i = 1;
            int u = 0;
            int j = 0;
            foreach (var vehicle in Car.ListOfVehicles)
            {
                if (vehicle.IsRented == true)
                {
                    Console.WriteLine($"{i} {vehicle.TypeOfCar}");
                    Console.WriteLine("Manufacturer:", vehicle._manuf);
                    Console.WriteLine("RegistrationNr:", vehicle.RegistrationNumber);
                    Console.WriteLine("This car is currently not availible");
                    //  Console.WriteLine($"Rented by: {User._customerList[u]}");
                    Console.WriteLine("Available for rent again:", ReturnDates[j]); //Mattis testar
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine();
                    u++;
                    i++;
                    j++;
                }
            }
            Console.ReadLine();
            MainClass.ShowMainMenu();
        }

        /*
         Display a list of all available Cars that are not rented
         */
        public void listAvailableCars()
        {
            SetTotalVehiclesInFleet();
        }

        //Calculate rent
        public void CalculateRent()
        {
            DateTime startTime = DateTime.Now;
            DateTime endTime;
            int hours = 0;
            int days = 0;

            Car v1 = new Car();
            v1 = Car.ListOfVehicles[MainClass.userInputVehicleChoice - 1];

            Truck t1 = new Truck();
            Sedan s1 = new Sedan();


            if (MainClass.userInputVehicleChoice > 0 && MainClass.userInputVehicleChoice <= 5)
            {
                t1 = (Truck)Car.ListOfVehicles[MainClass.userInputVehicleChoice - 1];
            }
            if (MainClass.userInputVehicleChoice > 5 && MainClass.userInputVehicleChoice <= 15)
            {

                s1 = (Sedan)Car.ListOfVehicles[MainClass.userInputVehicleChoice - 1];
            }
            //if (v1.TypeOfCar == "TRUCK")
            //{
            //  //  Truck.inputCargo(t1);
            //}

            Console.WriteLine("For how long do you wish to rent the vehicle?");
            Console.WriteLine("1: A couple of hours");
            Console.WriteLine("2: A day or more");
            userInputSwitch = int.Parse(Console.ReadLine());
            while (userInputSwitch > 2)
            {
                Console.Write("You must choose a number between 1 and 2: ");
                userInputSwitch = int.Parse(Console.ReadLine());
            }

            switch (userInputSwitch)
            {
                //This case is for getting the rent for 1 day.
                case 1:
                    //Type Sedan
                    if (v1.TypeOfCar == "SEDAN")
                    {
                        Console.Write("Enter hours you wish to rent a Car:");
                        hours = Convert.ToInt32(Console.ReadLine());
                        if (hours >= 24)
                        {
                            while (hours >= 24)
                            {
                                Console.WriteLine("Please enter hour amount below 24h or choose option Days");
                                hours = Convert.ToInt32(Console.ReadLine());

                            }
                        }
                        if (hours < 24)
                        {
                            if (s1.isElectric == true)
                            {
                                totalCost = hours * HourFee * (1M - ElectricDiscount());
                            }
                            else if (s1.isElectric == false)
                            {
                                totalCost = hours * HourFee;
                            }

                        }

                        SetTotalVehiclesInFleet();
                        endTime = startTime.AddHours(hours);
                        Console.WriteLine("\nWe expect the vechicle back at: " + endTime);
                        ReturnDate = endTime;
                        ReturnDates.Add(ReturnDate);

                    }
                    //Type TRUCK
                    if (v1.TypeOfCar == "TRUCK")
                    {
                        Console.Write("Enter hours you wish to rent a truck: ");
                        hours = Convert.ToInt32(Console.ReadLine());
                        if (hours < 24)
                        {
                            totalCost = hours * HourFee;

                        }
                        else if (hours >= 24)
                        {
                            while (hours >= 24)
                            {
                                Console.WriteLine("Please enter hour amount below 24h or choose option Days");
                                hours = Convert.ToInt32(Console.ReadLine());
                            }
                            totalCost = hours * HourFee;
                        }
                        SetTotalVehiclesInFleet();
                        endTime = startTime.AddHours(hours);
                        Console.WriteLine("\nWe expect the vechicle back at: " + endTime);
                        ReturnDate = endTime;
                        ReturnDates.Add(ReturnDate);

                    }
                    break;
                //This case is for getting the rent over a week

                case 2:
                    //Type Sedan
                    if (v1.TypeOfCar == "SEDAN")
                    {
                        Console.Write("Enter amount of days:");
                        days = Convert.ToInt32(Console.ReadLine());
                        if (days >= 7 && s1.isElectric == true)
                        {
                            totalCost = days * v1.DailyPrice * (1 - ElectricDiscount() - OverOneWeekDiscount());

                        }
                        else if (days >= 7 && s1.isElectric == false)
                        {
                            totalCost = days * v1.DailyPrice * (1 - OverOneWeekDiscount());
                        }
                        else if (days < 7 && s1.isElectric == true)
                        {
                            totalCost = days * v1.DailyPrice * (1 - ElectricDiscount());
                        }
                        else
                        {
                            totalCost = days * v1.DailyPrice;
                        }
                    }
                    //Type TRUCK
                    if (v1.TypeOfCar == "TRUCK")
                    {
                        Console.Write("Enter amount of days:");
                        days = Convert.ToInt32(Console.ReadLine());
                        if (days >= 7)
                        {
                            totalCost = days * v1.DailyPrice * (1 - OverOneWeekDiscount());

                        }
                        if (days < 7)
                        {
                            totalCost = days * v1.DailyPrice;
                        }

                    }
                    SetTotalVehiclesInFleet();
                    endTime = startTime.AddDays(days);
                    Console.WriteLine("\n We expect the vechicle back at: " + endTime);
                    ReturnDate = endTime;
                    ReturnDates.Add(ReturnDate);
                    break;
            }

        }

        public decimal OverOneWeekDiscount()
        {
            decimal discount = 0.1m;
            return discount;

        }
        public decimal ElectricDiscount()
        {
            decimal discount = 0.1M;
            return discount;
        }

    }
}
