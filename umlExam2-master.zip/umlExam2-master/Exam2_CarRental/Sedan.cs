﻿using System;
using System.Collections.Generic;


namespace Exam2_CarRental
{

    public class Sedan : Car
    {

        public int Seats;
        public bool isElectric;
        private List<Sedan> sedanList = new List<Sedan>();

        //Sedan constructor with parameters
        public Sedan(string typeOfCar, Maker manuf, string regNr, decimal dayPrice, int numbSeats, bool isElect, bool isRent, bool isRentWeek)
                                : base(typeOfCar, manuf, regNr, dayPrice, isRent, isRentWeek)
        {
            TypeOfCar = typeOfCar;
            _manuf = manuf;
            RegistrationNumber = regNr;
            DailyPrice = dayPrice;
            Seats = numbSeats;
            isElectric = isElect;
            IsRented = isRent;

        }
        public static void CreateSedanList()
        {
            Sedan Saab1 = new Sedan("SEDAN", Maker.SAAB, "JON001", 6000, 4, false, false, true);
            Sedan Saab2 = new Sedan("SEDAN", Maker.SAAB, "EGH002", 6500, 4, true, false, true);

            Sedan Tesla = new Sedan("SEDAN", Maker.Tesla, "DAN001", 700, 4, false, false, true);
            Sedan Tesla1 = new Sedan("SEDAN", Maker.Tesla, "SOD007", 1200, 4, true, false, true);

            Sedan Tata1 = new Sedan("SEDAN", Maker.Tata, "MAT001", 6001, 4, false, false, true);
            Sedan Tata2 = new Sedan("SEDAN", Maker.Tata, "VAI002", 6501, 4, true, false, true);

            Sedan Volvo1 = new Sedan("SEDAN", Maker.Volvo, "AND001", 5600, 4, false, false, true);
            Sedan Volvo2 = new Sedan("SEDAN", Maker.Volvo, "PON002", 6100, 4, true, false, true);

            Sedan.ListOfVehicles.Add(Saab1);
            Sedan.ListOfVehicles.Add(Saab2);
            Sedan.ListOfVehicles.Add(Tesla);
            Sedan.ListOfVehicles.Add(Tesla1);
            Sedan.ListOfVehicles.Add(Tata1);
            Sedan.ListOfVehicles.Add(Tata2);
            Sedan.ListOfVehicles.Add(Volvo1);
            Sedan.ListOfVehicles.Add(Volvo2);
        }
        // Method that shows every car we have in the ListOfSedans
        public static void ShowAllSedans()
        {
            int i = 6;
            foreach (var car in ListOfVehicles)
            {
                if (car.TypeOfCar == "SEDAN")
                {
                    if (car.IsRented == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                    }
                    printSedan((Sedan)car, i);
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine();
                    i++;
                }
            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static void printSedan(Sedan sedan, int i)
        {
            Console.WriteLine($"{i} {sedan.TypeOfCar}");
            Console.WriteLine($"Manufacturer: { sedan._manuf}");
            Console.WriteLine($"Registration number: {sedan.RegistrationNumber}");
            Console.WriteLine($"Day Price: {sedan.DailyPrice}");
            Console.WriteLine($"Number of seats: { sedan.Seats}");

            if (sedan.isElectric == true)
                Console.WriteLine("This is an electric car");
            if (sedan.IsRented == false)
                Console.WriteLine("This car is availible");
            if (sedan.IsRented == true)
                Console.WriteLine($"[RENTED] Avalible again: {Rental.ReturnDates}");   //lägg in datetime för när tillgänglig igen
            //Console.WriteLine($"Electric: { sedan.IsElectric}");
            //Console.WriteLine($"Rented: {sedan.IsRented}");
        }



        public Sedan()
        {

        }
    }
}
