﻿namespace Exam2_CarRental
{
    public class Truck : Car
    {
        public static int CargoCapacity { get; set; }

        public Truck(string typeOfCar, Maker manuf, string regNr, decimal dayPrice, int cargoCap, bool isRent, bool isRentWeek)
           : base(typeOfCar, manuf, regNr, dayPrice, isRent, isRentWeek)
        {
            TypeOfCar = typeOfCar;
            _manuf = manuf;
            RegistrationNumber = regNr;
            DailyPrice = dayPrice;
            CargoCapacity = cargoCap;
            IsRented = isRent;
            IsRentedForMoreThenAWeek = isRentWeek;
        }
        public static void CreateTruckList()
        {

        }
        public static void ShowAllTrucks()
        {
        }
        public static void printTruck()
        {
        }
        public Truck()
        {

        }
    }
}
