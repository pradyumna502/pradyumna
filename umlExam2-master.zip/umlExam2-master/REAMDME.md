Abstract class Car has variables of Plate, price, maker and a collection of Rental class.
It has methods to list cars of certain maker and if car is available and the 
total number of cars in the fleet.

The child class of Sedan inherits from abstract class Car and has a variable of
seats. 
It implements two methods from the interfaces of IElectric, addCharge() and ICombustion, addFuel().

The child class of Truck inherits from abstract class Car and has a variable of
capacity it can transport. 
It implements method from the interface of ICombustion, addFuel().

The collection class of Rental has a collection of all rentals, the variables are
star date of rental, return date of rental, the Car itself and Customer, and the
status of rental, if true or false to able to rent.
The method complete shows status or if its still in progress of being rented, and
the count of all rentals in progress (Car.Plate, start and end date and Customer
and total number of all cars rented of the total number of cars in the fleet)

The Customer class has the variables of Name, list of car rentals.
The methods for this class have the car and rental and the finish method to end
the rental of the car.